/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package linkedlistw4;

/**
 *
 * @author U0033257
 */
public class LinkedList {
    
    //instance variables
    ListNode head;
    
    public LinkedList(){
        head = null;
    }
    
    public void addFirst(int obj){
        //create the node with value obj as data
        ListNode n = new ListNode(obj);
        //attach node n at the beginning of the list
        n.next = head;
        // update the value of head
        head = n;
    }
    
    public String listToString(){
        ListNode current = head;
        String output = "";
        while(current != null){
            output = output + current.data +" ";
            current = current.next;
        }
        return output;
    } 
    
    public int getFirst(){
        if(head==null)
            return 999;
        else
            return  head.data;
    }
    
    public int getSize(){
        ListNode current = head;
        int counter = 0;
        while(current!=null){
            counter++;
            current = current.next;
        }
        return counter;
    }
    
    public void addLast(int obj){
        //create the new node
        ListNode n = new ListNode(obj);
        ListNode current = head;
        //move the pointer current to the last node
        while(current.next!=null){
            current = current.next;
            System.out.println("I'm visiting node: " +current.data);
        }
        System.out.println("Here out of the while loop");
        current.next = n;
    }
    
    public int getLast(){
        ListNode current = head;
        if(head == null)
            return 999;
        else{
            //go to the last node
            while(current.next!=null){
            current = current.next;
            }
        return current.data;
        }

    }
}
