/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linkedlistw4;

/**
 *
 * @author U0033257
 */
public class LinkedListW4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        // TODO code application logic here
//        //int[] a = new int[5];
//        ListNode a = new ListNode(6);
//        System.out.println(a.data);
//        System.out.println(a.next);
//        ListNode b = new ListNode(7);
//        // a -> b 
//        a.next = b;
//        System.out.println("a.next.data "+a.next.data);
//        System.out.println("a.next.next "+a.next.next);
//        
//        LinkedList lL = new LinkedList();
//        System.out.println("lL.head: " +lL.head);
//        lL.addFirst(4);
//        lL.addFirst(1);
//        lL.addFirst(7);
//        lL.addFirst(9);
//        lL.addFirst(91);
//        lL.addFirst(95);
//        System.out.println("lL.head.data: " + lL.head.data);
//        //print the second item
//        System.out.println("The second item is: "+ lL.head.next.data);
//        System.out.println("The third item is: "+ lL.head.next.next.data);
//
//        System.out.println("List to String: "+lL.listToString());
//        
        //Week 5
        LinkedList lL2 = new LinkedList();
        System.out.println("The first node of the empty list is: "+ lL2.getFirst());
        lL2.addFirst(1);
        lL2.addFirst(4);
        lL2.addFirst(7);
        System.out.println("The new list contains:  "+ lL2.listToString());
        System.out.println("The first node is: "+ lL2.getFirst());
        System.out.println("The size of the list is: "+lL2.getSize());
        lL2.addLast(5);
        System.out.println("The new list contains:  "+ lL2.listToString());
        System.out.println("The last node is : "+lL2.getLast());
    }
    
}
