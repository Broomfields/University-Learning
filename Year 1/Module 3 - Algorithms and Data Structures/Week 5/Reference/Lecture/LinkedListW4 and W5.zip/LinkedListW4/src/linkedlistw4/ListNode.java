/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package linkedlistw4;

/**
 *
 * @author U0033257
 */
public class ListNode {
    
    //instance variables
    int data;
    ListNode next;
    
    //constructor
    public ListNode(){
        data = 0;
        next = null;
    }
    
    //constructor 2
    public ListNode(int obj){
        data =  obj;
        next = null;
    }
    
    //contructor 3
    public ListNode(int obj, ListNode n){
        data = obj;
        next = n;
    }
}
