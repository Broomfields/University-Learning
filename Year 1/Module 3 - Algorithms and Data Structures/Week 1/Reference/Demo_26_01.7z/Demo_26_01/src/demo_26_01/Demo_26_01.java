/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo_26_01;

/**
 *
 * @author U0033257
 */
public class Demo_26_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] a = new int[5];
        ArrayADT x = new ArrayADT(6);
        int[] b = {1,2,3};
        a[0] = 3;
        a[1] = 5;
        for(int i=0; i<b.length;i++){
            System.out.print(b[i] + " "); 
        }
        System.out.println("\n The ..." + a.length);
        System.out.println(a[2]);
        //print the array
        //a.print();
        //a.getSeconditem();
        x.getFirstItem();
        //add
        x.add(1);
        x.add(8);
        x.add(8);
        x.add(4);
        x.add(8);
        x.print();
       // x.insert(7, 1);
        x.print(); 
        x.getFrequencyOf(8);
        System.out.println("There are " + x.getFrequencyOf(8) + " 8s;" );
                
    }
    
}
