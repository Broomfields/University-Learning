/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo_26_01;

/**
 *
 * @author U0033257
 */
public class ArrayADT {
    //instance fields
    private int[] data;
    private int numberOfEntries;
    
    //constructor
    public ArrayADT(int size){
        System.out.println("I'm creating a new array of size "+size);
        data = new int[size];
        numberOfEntries = 0;
    }
    
    public void getFirstItem(){
        System.out.println("The first item is "+data[0]);
    }
    
    //add a new item
    public void add(int n){
        data[numberOfEntries] = n;
        numberOfEntries++;
    }
    
    
    public void print(){
        for(int i=0; i<data.length;i++){
            System.out.print(data[i] +" ");
        }    
        System.out.println("");
    }
    
    //insert obj o at index i
    public void insert(int o, int index){
        data[index] = o; //ArrayADT.add(o);
    }
    
    public int getFrequencyOf(int item){
        int counter = 0;
        int index = 0; //starting at the first position
        while(index < data.length){
            System.out.println("I'm checking item at index: " +index);
            if(data[index]==item){
                counter++;
                index++;
            }
            else{
                index++;
            }     
        }
        return counter;
    }
    
}
