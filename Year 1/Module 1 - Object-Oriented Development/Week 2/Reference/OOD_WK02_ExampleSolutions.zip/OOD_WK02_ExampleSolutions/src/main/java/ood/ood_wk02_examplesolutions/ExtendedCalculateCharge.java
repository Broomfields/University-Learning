/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk02_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class ExtendedCalculateCharge {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        
        // get age
        System.out.print("Enter your age (years): ");
        int age = scan.nextInt();
        System.out.printf("You put %d\n", age);
        
        double charge = 30.0; // assume that user is >=18
        
        // if age is less than 18 set charge 60% of adult charge
        if (age < 18) {
            charge *= 0.6;
        } // else if age greater than 65 set charge to 80% of adult charge
        else if(age > 65) {
            charge *= 0.8;
        }
        
        //System.out.println("Hi, you are " + age + 
        //        " so must pay Â£" + charge);
        
        System.out.printf("Hi, you are %d so must pay \u00A3%.2f\n", age, charge); // \u00A3 inserts a £ symbol on Unix-like environments
    }
}
