/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk02_examplesolutions;

/**
 *
 * @author steven
 */
public class BankWithdrawal {
    public static void main(String[] args) {
        int balance = 40;
        int overdraft = -50;
        
        int withdraw = 100;
        
        System.out.print("Withdraw: " + withdraw);
        
        // Transaction
        balance -= withdraw;
        
        if(balance < 0) {
            System.out.print(" (Using Overdraft)");
            
            if(balance < overdraft) {
                System.out.print(" Charge: 5");
                balance -= 5;
            }
        }
        
        System.out.println(" New Balance: " + balance);
    }
}
