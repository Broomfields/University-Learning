/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk02_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class EmployeeManager {
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Please enter the hours worked: ");
        
        int hoursWorked = keyboard.nextInt();
        
        double weeklyWage = hoursWorked * 9.75;
        
        if(hoursWorked > 40) {
            int overtimeHoursWorked = hoursWorked - 40;
            
            weeklyWage += overtimeHoursWorked * 4.5;
        }
        
        System.out.println("Weekly wage = " + weeklyWage);
    }
    
}
