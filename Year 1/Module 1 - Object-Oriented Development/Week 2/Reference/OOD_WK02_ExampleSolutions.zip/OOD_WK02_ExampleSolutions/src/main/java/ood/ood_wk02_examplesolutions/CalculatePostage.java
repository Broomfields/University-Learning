/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk02_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class CalculatePostage {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Please enter the weight in kilograms: ");
        
        int weight = keyboard.nextInt();
        
        // Exercise 9(b)
        if(weight > 4) {
            System.out.println("Over 4 kilograms: 20.00");
        }
        else if(weight >= 3) {
            System.out.println("3 - 4 kilograms: 13.00");
        }
        else if(weight >= 2) {
            System.out.println("2 - 3 kilograms: 10.50");
        }
        else if(weight >= 1) {
            System.out.println("1 - 1 kilograms: 6.50");
        }
        else {
            System.out.println("Less that 1 kilogram: 3.50");
        }
        
        System.out.println("\n---------------------------------------\n");
        
        // Exercise 9(b)
        double cost;
        
        if(weight > 4) {
            cost = weight * 1.5;
        }
        else if(weight >= 3) {
            cost = weight * 2;
        }
        else if(weight >= 2) {
            cost = weight * 2.5;
        }
        else if(weight >= 1) {
            cost = weight * 3;
        }
        else {
            cost = weight * 3.5;
        }
        System.out.println("Postage Cost: " + cost);
    }
}
