/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk02_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class TemperatureConversion {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Do you want to convert [C]elsius to Fahrenheit of [F]ahrenheit to Celsius? ");
        
        char choice = keyboard.next().charAt(0);
        
        if(choice == 'C') {
            System.out.println("Please input the temperature in Celsius: ");
            
            double celsius = keyboard.nextDouble();
            
            double fahrenheit = celsius * 9 / 5.0 + 32;
            
            System.out.println(celsius + "C = " + fahrenheit + "F");
        }
        else if(choice == 'F') {
            System.out.println("Please input the temperature in Fahrenheit: ");
            
            double fahrenheit = keyboard.nextDouble();
            
            double celsius = (fahrenheit - 32) * 5 / 9;
            
            System.out.println(fahrenheit + "F = " + celsius + "C");
        }
    }
}
