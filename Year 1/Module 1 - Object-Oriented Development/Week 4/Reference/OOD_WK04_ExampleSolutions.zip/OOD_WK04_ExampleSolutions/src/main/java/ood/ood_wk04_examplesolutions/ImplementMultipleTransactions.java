/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk04_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class ImplementMultipleTransactions {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please input the loan amount: ");
        
        int loanAmount = input.nextInt();
        
        while(loanAmount >= 0) {
            
            System.out.println("Please enter the monthly payment: ");
            int monthlyPayment = input.nextInt();
            
            // Validate the user input.
            while(monthlyPayment > loanAmount) {
                System.out.println("Error! Monthly payment cannot be larger than the loan amount.");
                monthlyPayment = input.nextInt();
            }
            
            // Work out the payment plan...
            int balance = loanAmount;
            int month = 0;
            
            while(balance > 0) {
                balance = balance - monthlyPayment;
                
                if(balance < 0) {
                    balance = 0;
                }
                month++;
                
                System.out.println(month + "- Balance:" + balance);
            }
            
            // Get next loan amount.
            System.out.println("Please input the loan amount: ");
            loanAmount = input.nextInt();
        }
    }
}
