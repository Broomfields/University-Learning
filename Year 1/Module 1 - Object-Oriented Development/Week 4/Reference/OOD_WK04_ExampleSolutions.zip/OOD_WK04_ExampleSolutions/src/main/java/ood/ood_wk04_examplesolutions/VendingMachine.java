/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk04_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class VendingMachine {

    public static void main(String[] args) {

        //Display the menu to the user.
        System.out.println("Please choose your item:\n 1. Coke\n 2. Crisps\n 3. Chocolate\n 4. Water\n");

        //Get the selection from the user
        Scanner keyb = new Scanner(System.in);

        int choice = keyb.nextInt();

//        System.out.println(choice);

        //Validate the selection
        while (choice < 1 || choice > 4) {
            System.out.println("Wrong");
            System.out.println("Please enter again: ");
            choice = keyb.nextInt();
        }

        int charge;
        
        //Display the selection and amounts.
        if (choice == 1) {
            charge = 45;
            System.out.println("You picked Coke at " + charge);
        } else if (choice == 2) {
            charge = 35;
            System.out.println("You picked crisps at " + charge);
        } else if (choice == 3) {
            charge = 23;
            System.out.println("You picked chocolate bar at " + charge);
        } else {
            charge = 32;
            System.out.println("You picked water at " + charge);
        }

        //Get the payment amount.
        System.out.println("Please enter payment amount in pence: ");

        int payment = keyb.nextInt();

        int change = payment - charge;

        //Calculate change 
        int twenty = 0;
        int ten = 0;
        int five = 0;
        int two = 0;
        int one = 0;

        twenty = change / 20;
        change = change % 20;

        ten = change / 10;
        change = change % 10;

        five = change / 5;
        change = change % 5;

        two = change / 2;
        change = change % 2;

        one = change;

        System.out.println("Your change is " + (payment - charge) + " This is made up of ");
        System.out.println("20p " + twenty + " 10p " + ten + " 5p " + five + " 2p " + two + " 1p " + one);

    }
}
