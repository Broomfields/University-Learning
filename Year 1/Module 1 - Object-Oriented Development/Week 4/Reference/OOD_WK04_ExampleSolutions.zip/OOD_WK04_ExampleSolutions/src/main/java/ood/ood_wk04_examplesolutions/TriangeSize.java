/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk04_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class TriangeSize {

    public static void main(String[] args) {
        //Q5a
        System.out.println("Please enter a triangle size less than 20: ");
        Scanner keyb = new Scanner(System.in);

        int size = keyb.nextInt();

        while (size >= 20 || size <= 0) {
            System.out.println("Size not valid, please try again");
            System.out.println("Please enter a triangle size less than 20: ");
            size = keyb.nextInt();
        }
        System.out.println("You have entered a valid triangle size\n\n");

        // Q5b
        System.out.println("Please enter a triangle size, size must be an odd number between 3 and 19 inclusive: ");
        size = keyb.nextInt();
        while ((size % 2 == 0) || size < 3 || size > 19) {
            System.out.println("Size not valid, please try again");
            System.out.println("Please enter a triangle size, size must be an odd number between 3 and 19 inclusive: ");
            size = keyb.nextInt();
        }
        System.out.println("You have entered a valid triangle size");
    }
}
