/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk04_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class CountingNumbers {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        int positiveNumbers = 0;
        int negativeNumbers = 0;
        
        while(true) {
            System.out.println("Please enter a number, 0 to finish");
            int number = input.nextInt();
            
            if(number == 0) {
                break;
            }
            else if(number < 0) {
                negativeNumbers++;
            }
            else if(number > 0) {
                positiveNumbers++;
            }
        }
        
        System.out.println("Number of +ve values: " + positiveNumbers);
        System.out.println("Number of -ve values: " + negativeNumbers);
    }
}
