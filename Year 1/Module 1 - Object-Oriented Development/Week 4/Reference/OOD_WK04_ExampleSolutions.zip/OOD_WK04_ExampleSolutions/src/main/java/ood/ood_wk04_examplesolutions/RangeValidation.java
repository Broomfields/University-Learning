/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk04_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class RangeValidation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter a number between 1 and 100");
        
        while(true) {
            
            int value = input.nextInt();
            
            if(value >= 1 && value <= 100) {
                break;
            }
            System.out.println("Please reenter the number.");
        }
    }
}
