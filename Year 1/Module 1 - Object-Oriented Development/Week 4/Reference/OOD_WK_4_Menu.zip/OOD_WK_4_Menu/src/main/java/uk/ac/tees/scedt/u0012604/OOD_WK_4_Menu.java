/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package uk.ac.tees.scedt.u0012604;

import java.util.Scanner;

/**
 *
 * @author U0012604
 */
public class OOD_WK_4_Menu {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        int option;
        
        do {
            System.out.println("Option [1]: Celsius (C) to Fahrenheit (F)");
            System.out.println("Option [2]: Fahrenheit (F) to Celsius (C)");
            System.out.println("Option [3]: Quit");
            
            option = input.nextInt();
            
            if(option < 1 || option > 3) { // Handle invalid choices
                System.out.println("** Error! Invalid option choice!");
            }
            
            else if(option == 1) { // Celsius (C) to Fahrenheit (F)
                System.out.println("Please input the temperature in Celsius");
                double celsius = input.nextFloat();
                //  F = 9 / 5 x C + 32
                double fahrenheit = 9.0 / 5 * celsius + 32;
                
                System.out.println(
                        String.format(
                            "%.2f (C) = %.2f (F)",
                            celsius,
                            fahrenheit));
            }
            else if(option == 2) { // Fahrenheit (F) to Celsius (C)
                // C = 5 x (F – 32) / 9
                System.out.println("Please input the temperature in Fahrenheit");
                double fahrenheit = input.nextFloat();
                
                double celsius = 5 * (fahrenheit - 32) / 9;
                
                System.out.println(
                        String.format(
                            "%.2f (F) = %.2f (C)",
                            fahrenheit,
                            celsius));                
            }
            // No need to handle else, 
            // loop will terminated if 
            // user entered 3.
            
        } while(option != 3);
        
        System.out.println("Program Terminated.");
    }
}
