/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class ContentsPage {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter the page width: ");
        int width = input.nextInt();
        
        if(width > 0 && width <= 50) {            
            // ------------------------------------------------------
            // Read the newline character left on the input stream...
            input.nextLine();
            // ------------------------------------------------------
            
            System.out.println("Please enter the chapter title: ");
            String chapterTitle = input.nextLine();
            
            System.out.println("Please enter the page number: ");
            int pageNumber = input.nextInt();
            
            int numberOfDots = width - chapterTitle.length();
            
            if(pageNumber >= 1000) {
                numberOfDots -= 4;
            }
            else if(pageNumber >= 100) {
                numberOfDots -= 3;
            }
            else if(pageNumber >= 10) {
                numberOfDots -= 2;
            }
            else {
                numberOfDots -= 1;
            }
            
            String contentsPageEntry = chapterTitle + ".".repeat(numberOfDots) + pageNumber;
            
            System.out.println(contentsPageEntry);
            
            // Check length is correct
            System.out.println(contentsPageEntry.length() == width);
        }
        else {
            System.out.println("Invalid width.");
        }
    }
}
