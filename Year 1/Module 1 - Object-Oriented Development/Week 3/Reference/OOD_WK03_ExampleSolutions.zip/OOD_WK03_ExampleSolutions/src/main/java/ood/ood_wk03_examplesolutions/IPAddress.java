/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author steven
 */
public class IPAddress {
    public static void main(String[] args) {
        String ipAddr = "255.255.255.255";
        
        /*
            Long-winded solution...
        */
        String[] octets = ipAddr.split("[.]"); // split the IP address into the individual "octets" as they're known
                
        boolean validIp = octets.length == 4; // should have 4 strings
        
        if(validIp) {
            // check each octet
            for(String octet : octets) { 
                
                // make sure it isn't empty
                validIp = !octet.isEmpty();
                
                // check each character is a digit
                for(
                        int charIdx = 0;
                        charIdx < octet.length() && validIp; // <-- note the conditional expression
                        charIdx++) { 
                    validIp = Character.isDigit(octet.charAt(charIdx));
                }
                
                // end loop if we've detected it isn't a valid IP, i.e. it contains non-digits
                if(!validIp) { 
                    break;
                }
                
                // Convert to an integer
                int asInt = Integer.parseInt(octet);
                
                // check it is in the allowable values 
                validIp = asInt >= 0 && asInt <= 255;
                
                // end loop if we've detected it isn't a valid IP, i.e. it contains non-digits 
                if(!validIp) {
                    break;
                }
            }
            
            // Output message
            if(!validIp) {
                System.out.println("Invalid IP Address");
            }
            else {
                System.out.println("Valid IP Address");
            }
        }
        else {
            System.out.println("Invalid IP Address");
        }
        
        /*
            Short-solution using a Regular Expression
        */
        System.out.println("\n-----------------------------------------------------------------------------\n");
        Pattern ipAddrPattern = Pattern.compile("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
        Matcher matcher = ipAddrPattern.matcher(ipAddr);
        
        if(matcher.find()) {
            System.out.println("Valid IP Address");
        }
        else {
            System.out.println("Invalid IP Address");
        }
    }
}
