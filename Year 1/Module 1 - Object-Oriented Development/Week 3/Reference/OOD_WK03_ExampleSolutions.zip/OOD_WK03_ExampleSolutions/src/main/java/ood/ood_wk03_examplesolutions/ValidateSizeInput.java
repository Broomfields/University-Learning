/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class ValidateSizeInput {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter a size.  Inputs can be Large, Small, L or S: ");
        
        String size = input.next().toUpperCase();
        
        if(size.equals("LARGE") || size.equals("L")) {
            System.out.println("Large");
        }
        else if(size.equals("SMALL") || size.equals("S")) {
            System.out.println("Small");
        }
        else {
            System.out.println("Invalid Size");
        }
    }
}
