/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class StaffNumber {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Input a staff number: ");
        
        String staffNumber= input.next();
        
        if(staffNumber.length() == 3 && staffNumber.charAt(0) >= 'A' && staffNumber.charAt(0) <= 'Z') {
            char firstDigit = staffNumber.charAt(1);
            char secondDigit = staffNumber.charAt(2);
            
            if(firstDigit >= '0' && firstDigit <= '9'&& 
               secondDigit >= '0' && secondDigit <= '9') {
               
                System.out.println("Valid Staff Number");
            }
            else {
                System.out.println("Positions 2 & 3 must be digits.");
            }
        }
        else {
            System.out.println("Invalid length or first position not an uppercase character");
        }
    }
}
