/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class InputString {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String name1 = input.next();
        String name2 = input.next();
        
        System.out.println(name1 + " length is " + name1.length());
        System.out.println(name2 + " length is " + name2.length());
        
        // 3(b)
        if(name1.length() <= name2.length()) {
            System.out.println(name1);
            System.out.println(name2);
        }
        else {
            System.out.println(name2);
            System.out.println(name1);
        }
        
        // 3(c)
        if(name1.length() == name2.length()) {
            System.out.println(name1 + " is the same length as " + name2);
        }
        
        // 3(d)
        System.out.println(name1.toUpperCase());
        System.out.println(name2.toLowerCase());
        
        // 3(e)
        System.out.println(name1);
        System.out.println(name2);       
    }
}
