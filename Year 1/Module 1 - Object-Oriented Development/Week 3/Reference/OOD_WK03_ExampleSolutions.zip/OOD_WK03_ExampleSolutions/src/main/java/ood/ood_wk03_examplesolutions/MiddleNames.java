/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class MiddleNames {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter your full name: ");
        String name = input.nextLine();
        
        // 4(a)
        int firstSpace = name.indexOf(' ');
     
        // 4(b)
        int lastSpace = name.lastIndexOf(' ');
        
        // 4(c)
        String middleName = name.substring(firstSpace, lastSpace);
        
        System.out.println("Middle Name = " + middleName);
    }
}
