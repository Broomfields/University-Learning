/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.ood_wk03_examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class FileExtension {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please input a file name: ");
        
        String fileName = input.nextLine();
        
        // Handle Linux filepaths
        int indexOfLastPathSeparator = fileName.lastIndexOf('/');
                
        // Ensure that we're using the actual filename from a Linux path
        // if we've got Linux path separators in the string.
        if(indexOfLastPathSeparator >= -1) {
            fileName = fileName.substring(indexOfLastPathSeparator + 1);
        }
        
        // Find the index of the file extension dot
        int indexOfDot = fileName.lastIndexOf('.');
        
        // Now work out if the file has an extension or not.
        if(indexOfDot > -1) {
            String fileExt = fileName.substring(indexOfDot + 1);
            
            System.out.println("The extension is: " + fileExt);
        }
        else {
            System.out.println("The file has no extension.");
        }
    }
}
