/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class LookupTableExtended1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String[] daysOfTheWeek = {
            "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday",
            "Saturday", "Sunday"
        };
        
        String[] monthsOfTheYear = {
            "January", "February", "March",
            "April", "May", "June",
            "July", "August", "September",
            "October", "November", "December"
        };
        
        
        String dayMonth;
        
        while(true) {
            System.out.println("Please enter a day of the week and month in the format D-MM (D=1 to 7, MM=01 to 12): ");
            dayMonth = input.next();
            
            // TODO: Validate that the date string only contains digits in positions 0, 2, and 3.
            
            int ordinalDay = Integer.parseInt(dayMonth.substring(0, 1));
            int ordinalMonth = Integer.parseInt(dayMonth.substring(2));
            
            if(ordinalDay >= 1 && ordinalDay <= 7 && ordinalMonth >= 1 && ordinalMonth <= 12) {
                System.out.println(daysOfTheWeek[ordinalDay - 1].toUpperCase() + " " + monthsOfTheYear[ordinalMonth - 1].toUpperCase());
                break;
            }
            
            System.out.println("Invalid date string");
        }
    }    
}
