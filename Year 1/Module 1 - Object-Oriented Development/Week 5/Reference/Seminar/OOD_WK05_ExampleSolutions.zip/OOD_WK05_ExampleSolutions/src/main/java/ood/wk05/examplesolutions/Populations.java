/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author steven
 */
public class Populations {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int[] population = new int[10];
                
        for(int index = 0; index < population.length; index++) {
            System.out.println(String.format("Please enter the age of person %d", index + 1));
            
            int age;
            
            while(true) {
                age = input.nextInt();
                if(age > 1 && age < 130) {
                    break;
                }
                System.out.println("Invalid age, please re-enter");
            }
            
            population[index] = age;
        }
        
        
        
        // Compute the min, max and mean average
        int minAge = population[0], maxAge = population[0];
        double meanAverage = population[0];
        
        for(int index = 1; index < population.length; index++) {
            int age = population[index];
            if(age < minAge)
                age = minAge;
            else if(age > maxAge)
                age = maxAge;
            
            meanAverage += age;
        }
        
        meanAverage /= population.length;
        
        // Compute the median average age.
        double medianAverage;
        
        // Sort the array in to ascending order
        Arrays.sort(population);
        
        // For odd number of ages in the population sample,
        // pick the middle value.
        if(population.length % 2 == 1) {
            medianAverage = population[population.length / 2];
        }
        // For even number of ages in the population sample,
        // take an average of the middle 2 values.
        else {
            int middle = population.length / 2;
            medianAverage = (population[middle] + population[middle+1]) / 2.0;
        }
        
        // Output the results.
        System.out.println("Minimum age: " + population[0]);
        System.out.println("Maximum age: " + population[population.length - 1]);
        System.out.println("Mean average age: " + meanAverage);
        System.out.println("Median average age: " + medianAverage);
    }
}
