/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ood.wk05.examplesolutions;

import java.util.Random;

/**
 *
 * @author U0012604
 */
public class ConsecutiveValues {

    public static void main(String[] args) {
//                                                    1  1  1  1  1  1  1  1  1  1  2  2  2  2  2  2  2  2  2  2  3  3  3  3  3  3  3  3  3  3  3  4  4  4  4  4
//                      0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5      
//        int[] array = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 1, 2, 1, 2, 2, 2, 2, 8, 8, 8, 8, 8, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
//        int[] array = { 1, 2, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        int[] array = new int[100];
//        
        Random random = new Random();
//        
        // Generate the random values
        for(int idx = 0; idx < array.length; idx++) {
            array[idx] = random.nextInt(20);
        }
//        
        for(int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
        
        int start = 0, end = 0;
        int valueWithLongestRun = array[0];
        int currentConsecutive = 1;
        int longestConsecutiveRun = 0;
        int innerIdx = 0;
        
        // Outer loop to that is used for the start position for each
        // search for consecutive runs.
        // Note the way that the outerIdx value is updated.
        for(int outerIdx = 0; outerIdx < array.length; outerIdx = innerIdx) {
            
            // Inner loop to search ahead for values that are the same 
            // as the array element index by the outer loop.
            // Note the conditional test, particularly the AND part.
            for(innerIdx = outerIdx + 1;
                innerIdx < array.length && array[innerIdx] == array[outerIdx];
                innerIdx++) {
                currentConsecutive++;
//                System.out.println(innerIdx + " " + array[innerIdx]);
            }
            
            // Check if the consecutive run count need updating.
            if(currentConsecutive > longestConsecutiveRun) {
                innerIdx--; // Adjust for the loop incrementation
                end = innerIdx; // Record the end index of the consecutive run
                start = outerIdx; // Record the start index of the consecutive run
                
                longestConsecutiveRun = currentConsecutive;
                valueWithLongestRun = array[end];
            }
            
            // Reset the consecutive counter for the next iteration
            // of the outer loop.
            currentConsecutive = 1;
            
//            System.out.println("Largest Consective So Far: " + longestConsecutiveRun);
        }
        
        System.out.println("Longest consecutive run: " + longestConsecutiveRun);
        System.out.println("Value with the longest run: " + valueWithLongestRun);
        System.out.println("Start index of run: " + start);
        System.out.println("End index of run: " + end);
    }
}
