/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

/**
 *
 * @author steven
 */
public class CoinToss {
    public static void main(String[] args) {
        
        boolean[] coinTosses = new boolean[100];
        
        for(int index = 0; index < coinTosses.length; index++) {
            int randomNum = (int)(Math.random() * 2);
            
            coinTosses[index] = randomNum == 0;
        }
        
        int headsCount = 0, tailsCount = 0;
        
        for(boolean ct : coinTosses) {
            if(ct)
                headsCount++; // could have done this in the loop above,
            else              // but that is going against the spirit
                tailsCount++; // of the exercise! :)
        }
        
        System.out.println("Heads Count: " + headsCount);
        System.out.println("Tails Count: " + tailsCount);
    }
}
