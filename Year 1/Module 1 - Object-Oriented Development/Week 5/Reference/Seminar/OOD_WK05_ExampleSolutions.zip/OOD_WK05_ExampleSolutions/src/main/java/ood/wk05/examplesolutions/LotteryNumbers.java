/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class LotteryNumbers {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int[] lotteryNumbers = new int[7];
        
        System.out.println("Please enter 7 numbers");
        
        String[] ballNames = { "First", "Second", "Third", "Forth", "Fifth", "Sixth", "Bonus Ball" };
        
        for(int index = 0; index < lotteryNumbers.length; index++) {
            System.out.println(
                    String.format("%-6s Number: ", ballNames[index])
            );
            
            int number;
            boolean found;
            do {
                found = false;
                number = keyboard.nextInt();
                
                for(int checkIndex = 0; checkIndex < lotteryNumbers.length && !found; checkIndex++) {
                    found = lotteryNumbers[checkIndex] == number;
                }
                
                if(found) {
                    System.out.println(String.format("The number (%d) has already been entered - please re-enter:", number));
                }
            } while(found);
            
            lotteryNumbers[index] = number;
        }
        
        for(int index = 0; index < lotteryNumbers.length; index++) {
            System.out.println(
                    String.format(
                        "%-6s Number: %-3d",
                        ballNames[index],
                        lotteryNumbers[index])
            );
        }
    }
}
