/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

import java.util.Random;

/**
 *
 * @author steven
 */
public class BasicArrays {
    public static void main(String[] args) {
        int[] array = { 12, 3, 4, 0, 5, 99, 10 };
        
        for(int index = 0; index < array.length; index++) { // <-- Use the array's length property
            System.out.printf("Index %d: Value: %d\n", index, array[index]);
        }
        
        Random random = new Random();
        
        // Part 3
        int randomNumber = random.nextInt(100);
        
        for(int value : array) {
            if(value == randomNumber) {
                System.out.println("Found the number!");
                break;
            }
        }
    }
}
