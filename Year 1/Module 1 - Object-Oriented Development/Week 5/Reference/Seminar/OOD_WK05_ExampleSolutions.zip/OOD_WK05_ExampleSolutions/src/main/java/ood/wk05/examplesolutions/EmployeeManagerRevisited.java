/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class EmployeeManagerRevisited {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter the number of employees: ");
        int employeeCount = input.nextInt();
        
        double[] employeesWages = new double[employeeCount];
        
        for(int index = 0; index < employeesWages.length; index++) {
            System.out.println("Enter hours worked for employee " + (index + 1) + ": ");
            int hoursWorked = input.nextInt();
            
            double weeklyWage = hoursWorked * 9.75;
            
            if(hoursWorked > 40) {
                int overtimeHoursWorked = hoursWorked - 40;

                weeklyWage += overtimeHoursWorked * 4.5;
            }
            
            employeesWages[index] = weeklyWage;
        }
        
        // Display the wages:
        double totalSalary = 0;
        
        for(int index = 0; index < employeesWages.length; index++) {
            System.out.println(String.format("Employee #%d:\t%5.2f", index + 1, employeesWages[index]));
            
            totalSalary += employeesWages[index];
        }
        System.out.println("----------------------");
        System.out.printf("Total: %15.2f\n", totalSalary);
        System.out.println("----------------------");
        
    }
}
