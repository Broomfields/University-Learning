/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk05.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class LookupTable {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String[] daysOfTheWeek = {
            "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday",
            "Saturday", "Sunday"
        };
        
        String[] monthsOfTheYear = {
            "January", "February", "March",
            "April", "May", "June",
            "July", "August", "September",
            "October", "November", "December"
        };
        
        
        int ordinalDay;
        
        while(true) {
            System.out.println("Please enter a day of the week [1-7] ");
            ordinalDay = input.nextInt();
            
            if(ordinalDay >= 1 && ordinalDay <= 7) {
                break;
            }
            
            System.out.println("Invalid Day");
        }
        
        int ordinalMonth;
        
        while(true) {
            System.out.println("Please enter a day of the month [1-12] ");
            
            ordinalMonth = input.nextInt();
            
            if(ordinalMonth >= 1 && ordinalMonth <= 12) {
                break;
            }
            
            System.out.println("Invalid Month");
        }
        
        System.out.println(daysOfTheWeek[ordinalDay - 1] + " " + monthsOfTheYear[ordinalMonth - 1]);
    }
}
