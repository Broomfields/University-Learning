/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errorhandling;

import java.util.Scanner;

/**
 *
 * @author U0029190
 */
public class TryCatchFinally {
    public static void main(String[] args) {
        getNum(1, 100);
    }

    static int getNum(int min, int max) {
        Scanner scan = new Scanner(System.in);
        int num = min - 1;
        
        do {
            try {
                System.out.printf("Input number %d - %d: ", min, max);
                num = scan.nextInt();
            }
            catch (Exception e) { // catches all exceptions
                System.out.println("Somehting went wrong!");
                num = min - 1;
                scan.next(); // reset Scanner
            } 
            finally { // use to clean up variable state
                System.out.println("I always run!");
            }
            
        } while (num < min || num > max);
        
        return num;
    }
}
