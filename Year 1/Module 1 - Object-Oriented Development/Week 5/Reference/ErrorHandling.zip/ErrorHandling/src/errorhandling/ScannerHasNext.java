/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errorhandling;

import java.util.Scanner;

/**
 *
 * @author U0029190
 */
public class ScannerHasNext {
    public static void main(String[] args) {
        getNum(1, 100);
    }

    static int getNum(int min, int max) {
        Scanner scan = new Scanner(System.in);
        int num = min - 1;
        
        do {
            System.out.printf("Input number %d - %d: ", min, max);
            
            if (scan.hasNextInt()) // returns true if the next is of type int
                num = scan.nextInt();
            else {
                System.out.println("That's not an int!");
                scan.next(); // clear the scanner 
            }
        } while (num < min || num > max);
        
        return num;
    }
}
