/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errorhandling;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author U0029190
 */
public class TryCatch {

    public static void main(String[] args) {
        getNum(1, 100);
    }

    static int getNum(int min, int max) {
        Scanner scan = new Scanner(System.in);
        int num = min - 1;
        
        do {
            try {
                System.out.printf("Input number %d - %d: ", min, max);
                num = scan.nextInt();
            }
            catch (InputMismatchException e) // i.e. user enters 'ten'
            {
                System.out.println("That's not a valid number!");
                num = min - 1;
                scan.next(); // reset Scanner
            }
            catch (Exception e) { // catches all other exceptions
                                  // must come last!
                num = min - 1;
                scan.next(); // reset Scanner
            } 
            
        } while (num < min || num > max);
        
        return num;
    }
}
