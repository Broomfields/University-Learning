/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errorhandling;

import java.util.Scanner;

/**
 *
 * @author James
 */
public class Citizenship {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter citizenship: ");
        String cit = scan.nextLine();
        
        System.out.print("Enter age: ");
        int age = scan.nextInt();
        
        // The following condition has a logic error...
        if (age > 18 && cit.equals("UK") || cit.equals("GB")) {
            System.out.println("You can vote!");
        }
        else
        {
            System.out.println("Cannot vote.");
        }
    }
    
}
