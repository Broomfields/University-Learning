/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.inheritancedemo;

/**
 *
 * @author steven
 */
public class Dog extends Animal {
    public Dog() {
        super();
    }
    
    public Dog(String n) {
        super(n);
    }
    
    public void talk() {
        System.out.println(
            String.format(
                "%s the %s, barked.",
                name,
                this.getClass().getSimpleName()
            )
        );
    }
}
