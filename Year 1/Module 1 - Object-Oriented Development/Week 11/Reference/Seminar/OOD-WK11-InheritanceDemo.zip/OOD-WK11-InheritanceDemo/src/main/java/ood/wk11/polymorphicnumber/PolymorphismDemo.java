/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ood.wk11.polymorphicnumber;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author u0012604
 */
public class PolymorphismDemo {
    public static void main(String[] args) {
        
        if(args.length == 0) {
            System.out.println("Usage: Please provide a number");
            
            return;
        }
        
        Number num;
        try {
            num = NumberFormat.getInstance().parse(args[0]);
            
            System.out.println("The number " + num.toString() + " has class " + num.getClass());
            
        } catch (ParseException ex) {
            Logger.getLogger(PolymorphismDemo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
