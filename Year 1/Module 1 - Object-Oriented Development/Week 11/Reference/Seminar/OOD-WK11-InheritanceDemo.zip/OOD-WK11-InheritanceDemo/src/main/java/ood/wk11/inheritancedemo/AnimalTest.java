/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.inheritancedemo;

import java.util.ArrayList;

/**
 *
 * @author steven
 */
public class AnimalTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cat myCat = new Cat("Felix");
        Dog myDog = new Dog("max");
        Cow myCow = new Cow("daisy");
        Animal myAnimal = new Animal();
        
        ArrayList<Animal> zoo = new ArrayList<>();
        
        zoo.add(myCat);
        zoo.add(myDog);
        zoo.add(myCow);
        zoo.add(myAnimal);
        
        for(Animal a : zoo) {
            a.talk();
        }
    }
}
