/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ood.wk11.inheritancedemo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author u0012604
 */
public class AnimalTest2 {
    public static void main(String[] args) throws IOException {
        // Load some animals from file.
        //
        ArrayList<Animal> zoo = readFromFile();
        
        // Iterate through the collection of animals and make them talk!
        //
        for(Animal animal : zoo) {
            animal.talk();
        }
    }
    
    /**
     * readFromFile()
     * 
     * @return An array list populated with Animal objects.
     */
    public static ArrayList<Animal> readFromFile() {
        final ArrayList menagarie = new ArrayList<>();
        
        // Open the file for reading
        final File menagarieFile = new File("data/menagerie.txt");
        
        try(final BufferedReader br = new BufferedReader(new FileReader(menagarieFile))) {
            
            String line;
            
            // Process each line and create the appropriate animal class
            //
            while((line = br.readLine()) != null) {
                Animal newAnimal = null;
                
                final String[] parts = line.split(",");
                
                // Some simple validation of the data read from the file.
                //
                if(parts.length != 2 || parts[0].isBlank() || parts[0].isEmpty() || parts[1].isBlank() || parts[1].isEmpty())
                    continue;
                
                // Determine whick type of animal to actually create.
                //
                switch(parts[0]) {
                    case "COW":
                        newAnimal = new Cow(parts[1]);
                        break;
                    case "CAT":
                        newAnimal = new Cat(parts[1]);
                        break;
                    case "DOG":
                        newAnimal = new Dog(parts[1]);
                        break; 
                }
                
                // If we were able to create an animal,
                // add it to the collection.
                if(newAnimal != null) {
                    menagarie.add(newAnimal);
                }
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AnimalTest2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AnimalTest2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Return the collection to the caller
        //
        return menagarie;
    }
}
