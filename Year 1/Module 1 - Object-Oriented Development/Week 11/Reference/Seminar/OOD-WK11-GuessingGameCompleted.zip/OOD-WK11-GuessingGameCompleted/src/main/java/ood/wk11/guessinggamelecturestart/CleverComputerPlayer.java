/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.guessinggamelecturestart;

import java.util.Arrays;

/**
 *
 * @author steven
 */
public class CleverComputerPlayer extends ComputerPlayer {
    
    private int[] guesses = new int[5];
    private int guessAttempts = 0;
    
    private static int cleverComputerPlayerCounter = 1;
    
    public CleverComputerPlayer(int maxNumber) {
        super("Clever Computer Player " + cleverComputerPlayerCounter++, maxNumber);
        
        Arrays.fill(guesses, -1);
    }
    
    @Override
    public int guess() {
        
        boolean keepGuessing = true;
        
        int myGuess = -1;
        
        do {
            
            myGuess = super.guess();
            
        } while(guessedAlready(myGuess));
        
        guesses[guessAttempts % guesses.length] = myGuess;
        
        guessAttempts++;
        
        displayMemory();
        
        return myGuess;
    }
    
    private boolean guessedAlready(int guessValue) {
        System.out.print("Checking memory...");
        for(int previousGuess : guesses) {
            if(previousGuess == -1) {
                System.out.println("Not guessed " + guessValue + " before");
                return false;
            }
            
            if(previousGuess == guessValue) {
                System.out.println("Already tried " + guessValue);
                return true;
            }
        }
        
        System.out.println();
        return false;
    }
    
    private void displayMemory() {
        System.out.println("-----------------");
        for(int value : guesses) {
            if(value == -1)
                break;
            System.out.print(value + " ");
        }
        System.out.println("\n-----------------");
    }
    
}