/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.guessinggamelecturestart;

/**
 *
 * @author steven
 */
public class Player {
    protected final String name;
    protected int maxNumber;

    /**
     * Player() constructor
     * @param name
     * @param maxNumber 
     */
    public Player(String name, int maxNumber) {
        this.name = name;
        this.maxNumber = maxNumber;
    }
    
    /**
     * guess()
     * 
     * @return 
     */
    public int guess() {
        System.out.println("This method should not be called :)");
        return 0;
    }
    
    /**
     * getName()
     * 
     * @return 
     */
    public final String getName() {
        return name;
    }
}
