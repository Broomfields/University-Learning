/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.guessinggamelecturestart;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author steven
 */
public class JPRWK10GuessingGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new JPRWK10GuessingGame().playGame();
    }
    
    public void playGame() {
        final int MAX_TURNS = 5;
        final int MAX_NUMBER = 10;
        final int GUESS_NUMBER = new Random().nextInt(MAX_NUMBER + 1);
        
        ArrayList<Player> players = new ArrayList<>();
        
        players.add(new HumanPlayer(MAX_NUMBER));
        players.add(new ComputerPlayer(MAX_NUMBER));

        
        boolean gameWon = false;
        int turn = 0;
        
        while(!gameWon && turn++ < MAX_TURNS) {
            for(Player p : players) {
                int guess = p.guess();
                
                System.out.println(p.getName() + " has guessed " + guess);

                if(guess == GUESS_NUMBER) {
                    System.out.println(p.getName() + " has won the game!");
                    
                    gameWon = true;
                    break;
                }
                else {
                    System.out.println("Incorrect");
                }
            }
        }
        
        if(!gameWon) {
            System.out.println("---------------------------");
            System.out.println("No one won the game, shame!");
            System.out.println("---------------------------");
        }
    }  
}
