/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.guessinggamelecturestart;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author steven
 */
public class HumanPlayer extends Player {
    
    /**
     * HumanPlayer() - Constructor
     * 
     * @param maxNumber 
     */
    public HumanPlayer(int maxNumber) {
        super("Human Player", maxNumber);
    }
    
    /**
     * guess()
     * 
     * @return 
     */
    @Override
    public int guess() {
        
        return askPlayerForGuess();
    }
    
    /**
     * readInteger()
     * 
     * @return 
     */
    private int askPlayerForGuess() {
        Scanner input = new Scanner(System.in);
        
        while(true) {
            System.out.println("Please enter a number between 0 and " + maxNumber);
            try {
                int value = input.nextInt();
                if(value >= 1 && value <= maxNumber) {
                    return value;
                }
                
                System.out.println("Number out of range");
            }
            catch(InputMismatchException ime) {
                System.out.println("Invalid input");
                input.next();
            }
        }
    }
    
}
