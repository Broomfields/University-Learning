/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk11.guessinggamelecturestart;

import java.util.Random;

/**
 *
 * @author steven
 */
public class ComputerPlayer extends Player {
    
    private static int computerPlayerCounter = 1;
    
    private final Random random = new Random();
    
    /**
     * ComputerPlayer(int maxNumber)
     * 
     * @param maxNumber 
     */
    public ComputerPlayer(int maxNumber) {
        super("ComputerPlayer: " + computerPlayerCounter++, maxNumber);
    }
    
    /**
     * ComputerPlayer() - Constructor
     * @param name
     * @param maxNumber 
     */
    public ComputerPlayer(String name, int maxNumber) {
        super(name, maxNumber);
    }
    
    /**
     * guess()
     * 
     * @return 
     */
    @Override
    public int guess() {
        return random.nextInt(maxNumber + 1);
    }
}
