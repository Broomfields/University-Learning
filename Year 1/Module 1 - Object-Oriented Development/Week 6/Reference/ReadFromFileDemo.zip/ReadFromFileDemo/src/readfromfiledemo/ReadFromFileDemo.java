/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package readfromfiledemo;

import java.io.*;      //  for FileNotFoundException
import java.util.*;   // Scanner class 

/**
 *
 * @author u0005547
 */
public class ReadFromFileDemo {

    public static void main(String[] args) {
        Scanner input = null;  	// this is to keep the compiler happy
        // as the object initialisation is in a separate block					   						   
        try {
            
            input = new Scanner(new File("secrets.txt"));
            
        } catch (FileNotFoundException e) {
            System.out.println("File doesn't exist");
            System.exit(1);
        }

        while (input.hasNext()) {
            String name = input.next();
            int mark = input.nextInt();
            System.out.println(name + "\t" + mark);
        }

        input.close();

    }// end of main
}
