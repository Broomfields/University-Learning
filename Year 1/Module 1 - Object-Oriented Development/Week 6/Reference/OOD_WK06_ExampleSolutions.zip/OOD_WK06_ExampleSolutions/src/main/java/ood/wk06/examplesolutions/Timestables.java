/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class Timestables {

    public static void main(String[] args) {

        int rows = getPositiveInt("Please enter the first number: ");
        int cols = getPositiveInt("Please enter the second number: ");
        
        outputTimesTable(rows, cols);
    }

    public static int getPositiveInt(String prompt) {
        final String errorMessage = "Please enter a positive number only.";
        Scanner input = new Scanner(System.in);

        while (true) {
            try {
                System.out.println(prompt);

                int userInput = input.nextInt();

                if (userInput <= 0) {
                    System.out.println("** Error! Negative number or 0 entered. " + errorMessage);
                    continue;
                }

                return userInput;
            } catch (java.util.InputMismatchException ime) {
                System.out.println("** Error! Non-number entered. " + errorMessage);
                input.next();
            }
        }
    }

    public static void outputTimesTable(int rows, int columns) {
        for(int row = 1; row <= rows; row++) {
            for (int col = 1; col <= columns; col++) {
                System.out.printf("%4d", row * col);
            }
            System.out.println();
        }
    }
}
