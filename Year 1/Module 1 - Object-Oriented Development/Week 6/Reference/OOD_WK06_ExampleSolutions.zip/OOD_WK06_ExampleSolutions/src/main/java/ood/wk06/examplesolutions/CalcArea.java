/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class CalcArea {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Please enter width: ");
        int width = in.nextInt();
        
        System.out.println("Please enter height: ");
        int height = in.nextInt();
        
        System.out.println("\nThe area is: " + calcArea(width, height));
    }
    
    public static int calcArea(int width, int height) {
        return width * height;
    }
}
