/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class DecimalToBinary {

    public static void main(String[] args) {
        int number = getInt("Please enter a number to convert to binary");
        
        System.out.println(
            String.format("%d (decimal) = %s (binary)",
                    number,
                    dec2bin(number)));
    }
    
    /**
     * dec2bin()
     * 
     * @param number +ve integer to convert to a binary string.
     * @return 
     */
    public static String dec2bin(int number) {
        String result = "";
                
        while(number != 0) {
            
            if(number % 2 == 0) {
                result = "0" + result;
            }
            else {
                result = "1" + result;
            }
            
            number /= 2;
        }
        
        return result;
    }
    
    /**
     * dec2binBitmaskVersion()
     * 
     * Alternative version using a combination of
     * bit masking and bit shifting to determine 
     * whether a particular bit is 0 (off) or 1 (on) in
     * the underlying bit pattern representing
     * the number.
     * 
     * If the number is 23, the bit pattern 
     * in memory will be: 00010111
     * 
     * The mask value will only be powers of 2
     * 1, 2, 4, 8, 16, 32, and so on.
     * 
     * 1 << 1 = 2   (000000010)
     * 1 << 2 = 4   (000000100)
     * ...
     * 1 << 8 = 256 (100000000)
     * ... etc ...
     * 
     * 
     * When using the mask for 2, bit pattern 00000010
     * 00010111   (dec 23)
     * 00000010 & (dec  2 - mask value)
     * ----------
     * 00000010   = 2 - Indicates the bit for 2^1 is on
     * 
     * When using the mask for 8, bit pattern 00001000
     * 00010111   (dec 23)
     * 00001000 & (dec  8 - mask value)
     * ----------
     * 00000000   = 0 - Indicates the bit for 2^3 is off.
     * 
     * Each iteration the mask is shifted 1 place to the
     * left to the next power of 2 and the process masking
     * process is repeated until the mask value exceeds
     * the number.
     * 
     * [[ This is included for curiosity only! ]]
     * @param number +ve integer to convert to binary
     * @return 
     */
    public static String dec2binBitmaskVersion(int number) {
        String result = "";
        int mask = 1;
        while(number >= mask) {
            if((number & mask) != 0) {
                result = "1" + result;
            }
            else {
                result = "0" + result;
            }
            mask <<= 1; // shift the mask to the left
        }
        return result;
    }

    /**
     * getInt()
     * Requests the user to input a number and validates it.
     * 
     * @param prompt the prompt to display to the user.
     * @return the validate number.
     */
    public static int getInt(String prompt) {
        final Scanner input = new Scanner(System.in);

        while (true) {
            try {
                System.out.println(prompt);

                int userInput = input.nextInt();
                
                if(userInput >= 0) {
                    return userInput;
                }
                
                System.out.println("** Please enter a +ve number");

            } catch (java.util.InputMismatchException ime) {
                System.out.println("** Error! Non-number entered.");
                input.next();
            }
        }
    }
}
