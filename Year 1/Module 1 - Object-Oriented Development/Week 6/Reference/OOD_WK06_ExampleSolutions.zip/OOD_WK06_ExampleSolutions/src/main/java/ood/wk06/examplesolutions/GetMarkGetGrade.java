/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class GetMarkGetGrade {
    
    public static void main(String[] args) {
        int mark = getMark();
        System.out.println("The mark is: " + mark);
        
        char grade = getGrade(mark);
        System.out.println("The grade is: " + grade);
    }
    
    /**
     * getMark()
     * 
     * Gets an input from the user and validates 
     * it in the range 0 - 100.
     * @return int validated mark
     */
    public static int getMark() {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter a mark: ");
        
        while(true) {
            int mark = input.nextInt();
            
            if(mark >= 0 && mark <= 100) {
                return mark;
            }
            
            System.out.println("Error! Please enter a mark between 0 - 100");
        }
    }
    
    /**
     * getGrade(int mark)
     * 
     * Converts a numeric mark into a letter grade.
     * @param mark
     * @return char letter grade equivalent of the numerical mark.
     */
    public static char getGrade(int mark) {
        if(mark >= 70) {
            return 'A';
        }
        else if(mark >= 60) {
            return 'B';
        }
        else if(mark >= 50) {
            return 'C';
        }
        else if(mark >= 40) {
            return 'D';
        }
        
        return 'F';
    }
    
}
