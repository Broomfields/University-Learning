/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class BinaryToDecimal {
    public static void main(String[] args) {
        final String binary = getBinary();
        
        System.out.println(binary + " = " + bin2Dec(binary));
    }
    
    /**
     * getBinary()
     * 
     * @return 
     */
    public static String getBinary() {
        boolean validBinaryString = false;
        Scanner in = new Scanner(System.in);
        
        String binary;
        
        do {
            System.out.println("Enter a binary string: ");
            
            binary = in.next();
            
            int chIndex;
            
            for(chIndex = 0; chIndex < binary.length() && (binary.charAt(chIndex) == '0' || binary.charAt(chIndex) == '1'); chIndex++)
                /* intentionally empty for loop */  ;
            
            validBinaryString = chIndex == binary.length();
            
        } while(!validBinaryString);
                
        return binary;
    }
    
    /**
     * bin2Dec
     * 
     * @param binary
     * @return decimal value that the binary string represents.
     */
    public static int bin2Dec(String binary) {
        int value = 0;
        int shift = binary.length() - 1; // left is most-significant bit, right is least-significant bit
        
        for(char c : binary.toCharArray()) {
            if(c == '1') {
                value += 1 << shift; // Use bit shifting to calculate what to add to the running total
            }
            shift--;
        }
        return value;
    }
}
