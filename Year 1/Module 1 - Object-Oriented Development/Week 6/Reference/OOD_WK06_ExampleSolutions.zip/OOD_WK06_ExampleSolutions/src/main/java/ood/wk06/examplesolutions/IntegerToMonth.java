/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class IntegerToMonth {
    public static void main(String[] args) {
        int month = getMonth();
        
        outputMonth(month);
    }
    
    public static void outputMonth(int month) {
        // Note: Could have used a Lookup table like last week
        
        switch(month) {
            case 1:
                System.out.println("January");
                break;
            case 2:
                System.out.println("February");
                break;                
            case 3:
                System.out.println("March");
                break;                
            case 4:
                System.out.println("April");
                break;
            case 5:
                System.out.println("May");
                break;
            case 6:
                System.out.println("June");
                break;
            case 7:
                System.out.println("July");
                break;
            case 8:
                System.out.println("August");
                break;                
            case 9:
                System.out.println("September");
                break;                
            case 10:
                System.out.println("October");
                break;
            case 11:
                System.out.println("November");
                break;
            case 12:
                System.out.println("December");
                break;               
        }
    }
    
    /**
     * getMonth()
     * 
     * Gets an input from the user and validates 
     * it in the range 1 - 12.
     * @return int validated month
     */
    public static int getMonth() {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter a month number [1-12]: ");
        
        while(true) {
            int month = input.nextInt();
            
            if(month >= 1 && month <= 12) {
                return month;
            }
            
            System.out.println("Error! Please enter a month between 1 - 12");
        }
    }
}
