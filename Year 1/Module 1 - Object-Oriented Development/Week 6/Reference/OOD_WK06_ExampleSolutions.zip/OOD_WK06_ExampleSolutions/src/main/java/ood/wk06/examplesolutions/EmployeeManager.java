/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class EmployeeManager {
    
    public static void main(String[] args) {
        final String employeeName = getName();
        final String employeeStaffId = getStaffId();
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Please enter the hours worked: ");
        int hoursWorked = keyboard.nextInt();
        
        double weeklyWage = hoursWorked * 9.75;
        
        if(hoursWorked > 40) {
            int overtimeHoursWorked = hoursWorked - 40;
            
            weeklyWage += overtimeHoursWorked * 4.5;
        }
        
        final String output =
                String.format(
                        "The weekly wage for %s (%s) is %.2f",
                        employeeName,
                        employeeStaffId,
                        weeklyWage);
        
        System.out.println(output);
    }
    
    /**
     * isValidName()
     * 
     * @param name
     * @return 
     */
    public static boolean isValidName(String name) {
        return !(name.isEmpty() || name.isBlank());
    }
    
    /**
     * getName()
     * 
     * @return String that is the employee name
     */
    public static String getName() {
        Scanner in = new Scanner(System.in);
        
        String name;
        
        do {
            System.out.println("Please enter a name, must be at least 1 character long: ");
            name = in.nextLine();
        } while(!isValidName(name));
        
        return name;
    }
    
    /**
     * isValidStaffId()
     * 
     * @param staffId
     * @return 
     */
    public static boolean isValidStaffId(String staffId) {
        return  Character.isAlphabetic(staffId.charAt(0)) &&
                Character.isDigit(staffId.charAt(1)) &&
                Character.isDigit(staffId.charAt(2));
    }
    
    /**
     * getStaffId()
     * 
     * @return 
     */
    public static String getStaffId() {
        Scanner in = new Scanner(System.in);
        
        String staffId;
        
        do {
            System.out.println("Please enter a staff id in the format <LETTER><DIGIT><DIGIT>, for example D65: ");
            staffId = in.nextLine();
        } while(!isValidStaffId(staffId));
        
        return staffId.toUpperCase();
    }
    
}
