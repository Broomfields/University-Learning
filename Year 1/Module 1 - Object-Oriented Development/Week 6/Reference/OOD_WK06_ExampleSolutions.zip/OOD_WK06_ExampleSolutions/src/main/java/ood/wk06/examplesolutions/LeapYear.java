/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class LeapYear {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String output;
        
//        for(int year = 1900; year <= 2022; year++) {
//            output = String.format("Year: %d (is %s a leap year)", year, !isLeapYear(year) ? "not" : "");
//            System.out.println(output);
//            for(int month = 1; month <= 12; month++) {
//                output =
//                    String.format(
//                        "\tMonth: %d has %d days",
//                        month,
//                        daysInMonth(month, year));
//                System.out.println(output);
//            }
//        }
        
        int month = getNumber("Please enter a month", 1, 12);
        
        int year = getNumber("Please enter a year", 0, 9999);
        
        System.out.println(String.format("There are %d in that month.", daysInMonth(month, year)));
        
    }
    
    /**
     * isLeapYear()
     * 
     * Determines whether a given year is a leap year or not.
     * 
     * @param year
     * @return true if a leap year, false otherwise.
     */
    public static boolean isLeapYear(int year) {
        return year % 4 == 0 && year % 100 != 0 || (year % 400 == 0);
    }
    
    /**
     * daysInMonth()
     *
     * @param month
     * @param year
     * @return the number days in the given month, accounting for leap years.
     */
    public static int daysInMonth(int month, int year) {
        switch(month) {
            case 2:
                return isLeapYear(year) ? 29 : 28; // ? : is the ternary operator, and inline if/else
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 31;
        }
    }
    
    /**
     * getNumber()
     * 
     * @param min minimum value allowed
     * @param max maximum value allowed
     * @return the validated number
     */
    public static int getNumber(String prompt, int min, int max) {
        Scanner input = new Scanner(System.in);
        
        System.out.println(String.format("%s - Please enter a number between: [%d-%d]", prompt, min, max));
        
        while(true) {
            int number = input.nextInt();
            
            if(number >= min && number <= max) {
                return number;
            }
            
            System.out.println(String.format("Error! Please enter a mark between [%d-%d]", min, max));
        }
    }
}
