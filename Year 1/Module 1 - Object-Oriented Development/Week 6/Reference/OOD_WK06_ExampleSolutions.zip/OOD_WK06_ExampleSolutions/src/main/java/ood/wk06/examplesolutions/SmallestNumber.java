/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk06.examplesolutions;

import java.util.Scanner;

/**
 *
 * @author steven
 */
public class SmallestNumber {
    public static void main(String[] args) {
        int value1 = getNumber();
        int value2 = getNumber();
        int value3 = getNumber();
        
        int smallest = findSmallest(value1, value2, value3);
        
        System.out.println("The smallest value is: " + smallest);
    }
    
    public static int findSmallest(int value1, int value2, int value3) {
        if(value1 < value2 && value1 < value3)
            return value1;
        else if(value2 < value1 && value2 < value3)
            return value2;
        return value3;
    }
    
    /**
     * getNumber()
     * 
     * Gets an input from the user and validates 
     * it in the range 1 - 100 (inclusive).
     * @return int validated number
     */
    public static int getNumber() {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter a number [1-100]: ");
        
        while(true) {
            int month = input.nextInt();
            
            if(month >= 1 && month <= 100) {
                return month;
            }
            
            System.out.println("Error! Please enter a number between [1-100]:");
        }
    }
}
