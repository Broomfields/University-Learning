/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.lamp;

/**
 *
 * @author steven
 */
public class Lamp {
    // Properties
    private boolean state;
    
    // Constructor
    public Lamp() {
        this.state = false;
    }
    
    // Methods
    public void switchOn() {
        this.state = true;
    }
    
    public void switchOff() {
        this.state = false;
    }
    
    public boolean isState() {
        return this.state;
    }
}
