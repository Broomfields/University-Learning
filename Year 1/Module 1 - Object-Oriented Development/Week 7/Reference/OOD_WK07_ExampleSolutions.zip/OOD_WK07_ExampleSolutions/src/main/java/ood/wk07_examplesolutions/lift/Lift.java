/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.lift;

/**
 *
 * @author steven
 */
public class Lift {
    // Properties
    private int currentFloor;
    private int topFloor;
    private boolean doorsOpen = false;
    
    // Constructors
    public Lift() {
        this(0);
    }
    
    public Lift(int currentFloor) {
        this(currentFloor, 10);
    }
    
    public Lift(int currentFloor, int maxFloors) {
        this.currentFloor = currentFloor;
        this.topFloor = maxFloors;
    }
    
    // Methods

    public int getCurrentFloor() {
        return currentFloor;
    }

    public boolean isDoorsOpen() {
        return doorsOpen;
    }
    
    public void toggleDoors() {
        doorsOpen = !doorsOpen;
    }
    
    public void goUp() {
        if(currentFloor < topFloor) {
            if(!doorsOpen) {
                currentFloor++;
            }
            else
                System.out.println("Error lift doors not closed");
        }
        else
            System.out.println("Error already at the top floor");
    }
    
}
