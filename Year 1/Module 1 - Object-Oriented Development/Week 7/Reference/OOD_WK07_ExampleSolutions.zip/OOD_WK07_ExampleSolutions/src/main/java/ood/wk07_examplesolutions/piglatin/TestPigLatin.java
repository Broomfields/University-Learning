/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ood.wk07_examplesolutions.piglatin;

import java.util.Scanner;

/**
 *
 * @author U0012604
 */
public class TestPigLatin {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Please enter a sentence to convert to Pig Latin: ");
        
        String sentence = scanner.nextLine();
        
        String[] sentenceWords = sentence.split(" ");
        
        // Count extra spaces so that we don't create too many
        // PigLatinText objects
        int blankWordCount = 0;
        
        for(String s : sentenceWords) {
            if(s.isEmpty() || s.isBlank()) {
                blankWordCount++;
            }
        }
        
        // Create an array for the PigLatinText objects
        //
        int pigLatinSentenceSize = sentenceWords.length - blankWordCount;
        
        PigLatinText[] pigLatinSentence = new PigLatinText[pigLatinSentenceSize];

        int pigLatinWordIndex = 0;
        
        // Iterate through the sentence entered by the user
        // creating PigLatinText objects.
        for(String s : sentenceWords) {
            // Skip any empty/blank entries (the user may have typed extra spaces)
            if(s.isEmpty() || s.isBlank()) {
                continue;
            }
            
            // Store in the array
            pigLatinSentence[pigLatinWordIndex] = new PigLatinText(s);
            
            pigLatinWordIndex++;
        }
        
        // Output the PigLatinText-ified sentence.
        for(PigLatinText pigLatinText : pigLatinSentence) {
            System.out.print(pigLatinText.getPigLatinWord() + " ");
        }
        
        System.out.println();
        
//        String[] pigLatinSentence = ;
//        
//        PigLatinText plt = new PigLatinText("Hello");
//        System.out.println(plt.getPigLatinWord());
    }
}
