/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ood.wk07_examplesolutions.piglatin;

/**
 *
 * @author U0012604
 */
public class PigLatinText {
    private final String originalWord;
    private final String pigLatinWord;

    public PigLatinText(String originalWord) {
        this.originalWord = originalWord;
        this.pigLatinWord = convert(originalWord);
    }

    public String getOriginalWord() {
        return originalWord;
    }

    public String getPigLatinWord() {
        return pigLatinWord;
    }
    
    private String convert(String source) {
        if(source.length() < 2) {
            return source;
        }
        
        String output = source.substring(2) + source.charAt(0) + source.charAt(1) + "ay";
        return output;
    }
}
