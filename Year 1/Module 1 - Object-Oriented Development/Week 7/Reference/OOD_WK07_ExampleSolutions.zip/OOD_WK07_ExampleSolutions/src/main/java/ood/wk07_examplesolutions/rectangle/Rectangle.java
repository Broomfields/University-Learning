/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.rectangle;

/**
 *
 * @author steven
 */
public class Rectangle {
    private int width, height;

    public Rectangle() {
        this(1, 1);
    }
    
    public Rectangle(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    
    public int computeSurface() {
        return width * height;
    }
    
    public int computePerimeter() {
        return 2 * width + 2 * height;
    }
    
}
