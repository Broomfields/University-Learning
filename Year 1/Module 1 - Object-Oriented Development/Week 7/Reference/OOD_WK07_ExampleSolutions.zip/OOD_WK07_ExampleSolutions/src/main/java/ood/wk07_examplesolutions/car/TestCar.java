/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.car;

/**
 *
 * @author steven
 */
public class TestCar {
    public static void main(String[] args) {
        Car c1 = new Car(121, 'C', false),
            c2 = new Car(178, 'E', true),
            c3 = new Car(62, 'A', false);
        
        System.out.println("Car Name: c1");
        System.out.println("Top Speed: " + c1.getTopSpeed());
        System.out.println("Tax band: " + c1.getTaxBand());
        System.out.println("Turbo: " + c1.hasTurbo());
        
        System.out.println("Car Name: c2");
        System.out.println("Top Speed: " + c2.getTopSpeed());
        System.out.println("Tax band: " + c2.getTaxBand());
        System.out.println("Turbo: " + c2.hasTurbo());
        
        System.out.println("Car Name: c3");
        System.out.println("Top Speed: " + c3.getTopSpeed());
        System.out.println("Tax band: " + c3.getTaxBand());
        System.out.println("Turbo: " + c3.hasTurbo());
    }
}
