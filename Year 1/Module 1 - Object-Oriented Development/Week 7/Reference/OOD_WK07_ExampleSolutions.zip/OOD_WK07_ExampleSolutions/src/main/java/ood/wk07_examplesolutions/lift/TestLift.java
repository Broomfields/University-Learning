/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.lift;

/**
 *
 * @author steven
 */
public class TestLift {
    public static void main(String[] args) {
        Lift elevator = new Lift();
        
        // open the doors
        elevator.toggleDoors();
        
        elevator.goUp(); // will fail - doors are open
        
        // close the doors
        elevator.toggleDoors();
        
        elevator.goUp();
        elevator.goUp();
        
        System.out.println("The current floor is: " + elevator.getCurrentFloor());
        
        // Exercise 3.
        Lift glassElevator = new Lift(4);
        
        System.out.println("The current floor is: " + glassElevator.getCurrentFloor());
        
        // Exercise 4.
        Lift skyscaperLift = new Lift(0, 96);
        
        skyscaperLift.toggleDoors();
        skyscaperLift.toggleDoors();
        
        for(int n = 0; n < 100; n++) {
            skyscaperLift.goUp();
            System.out.println("Current floor is: " + skyscaperLift.getCurrentFloor());
        }
    }
}
