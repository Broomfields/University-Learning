/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.rectangle;

/**
 *
 * @author steven
 */
public class TestRectangle {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(10, 2);
        Rectangle r2 = new Rectangle();
    
        displayRectangle(r1);
        
        System.out.println();
        
        displayRectangle(r2);
    }
    
    public static void displayRectangle(final Rectangle r) {
        System.out.println(
            String.format(
                "Width: %d\nHeight: %d\nSurface Area: %d\nPerimeter: %d",
                r.getWidth(),
                r.getHeight(),
                r.computeSurface(),
                r.computePerimeter()
            )
        );        
    }
}
