/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.lamp;

/**
 *
 * @author steven
 */
public class TestLamp {

    public static void main(String[] args) {
        Lamp lamp1 = new Lamp();
        System.out.println("State is " + lamp1.isState());
        
        lamp1.switchOn();
        System.out.println("State is " + lamp1.isState());
        
        lamp1.switchOff();
        System.out.println("State is " + lamp1.isState());
    }
}
