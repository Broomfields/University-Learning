/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk07_examplesolutions.car;

/**
 *
 * @author steven
 */
public class Car {
    private int topSpeed;
    private char taxBand;
    private boolean turbo;
    
    public Car(int topSpeed, char taxBand, boolean turbo) {
        this.topSpeed = topSpeed;
        this.taxBand = taxBand;
        this.turbo = turbo;
    }

    public int getTopSpeed() {
        return topSpeed;
    }

    public char getTaxBand() {
        return taxBand;
    }

    public boolean hasTurbo() {
        return turbo;
    }
    
}
