/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.staticarrayclass;

/**
 *
 * @author steven
 */
public class MyArrayTest {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MyArray myArray = new MyArray();
              
        System.out.println("Before: " + myArray);
        
        for(int n = 0; n <= 10; n++) {
            myArray.insert(n, n * n);
        }
        
        System.out.println("Middle: " + myArray);
        
        myArray.insert(5, -99);
        
        System.out.println("After: " + myArray);
        
    }    
}
