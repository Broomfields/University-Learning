/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.staticarrayclass;

/**
 *
 * @author steven
 */
public class MyArray {
    private int[] array = null;
            
    public int get(int index) {
        if(array == null || index > array.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        return array[index];
    }
    
    public void insert(int position, int value) {
        if(array == null) {
            array = new int[1];
            array[0] = value;
            return;
        }
        
        if(position < 0 || position > array.length)
            throw new ArrayIndexOutOfBoundsException();
        
        // Create an array 1 bigger than the source array
        int[] newArray = new int[array.length + 1];
        
        // Copy the contents upto the position where we want our new
        // data to be inserted.
        for(int n = 0; n < position; n++) {
            newArray[n] = array[n];
        }
        
        // Insert our new value
        newArray[position] = value;
        
        // Copy the rest of the source array content after the insert position
        for(int n = position; n < array.length; n++) {
            newArray[n + 1] = array[n];
        }
        
        array = newArray;
    }
    
    @Override
    public String toString() {
        if(array == null) {
            return "[]";
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int index = 0; index < array.length - 1; index++) {
            sb.append(array[index]);
            sb.append(", ");
        }
        sb.append(array[array.length - 1]);
        sb.append("]");
        return sb.toString();
    }
}
