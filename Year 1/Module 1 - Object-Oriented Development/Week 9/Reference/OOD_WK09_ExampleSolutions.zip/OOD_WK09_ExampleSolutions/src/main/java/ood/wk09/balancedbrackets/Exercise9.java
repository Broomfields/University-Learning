/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.balancedbrackets;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

/**
 *
 * @author steven
 */
public class Exercise9 {

    public static void main(String[] args) {

        final List<String> TEST_STRINGS = Arrays.asList(
                "[ hello ( world < ! > ) ]",
                "[ hello ( world < ! ) > ]",
                "<<<<[[[[[[]]]]]]>>>>",
                "<<<<[[[[[]]]]]]>>>>",
                "<<<<[[[[[[[]]]]]]>>>>",
                "public static int main(String[] args){ /* some statements */ }",
                "<HELLO, WORLD![1234(ABC)]>",
                "<HELLO, WORLD![1234(ABC)[5678<DEF>]]>",
                "<HELLO, WORLD![1234(ABC)[5678<DEF>]]()>",
                "<THIS SHOULD FAIL!![1234(ABC)[5678<DEF>)]>");
        
        for(final String testString : TEST_STRINGS) {
            if(BalancedBracketTester2.test(testString)) {
                System.out.println(testString + " is balanced");
            }
            else {
                System.out.println(testString + " is not balanced");
            }
        }
    }
}

class BalancedBracketTester2 {
    /**
     * test()
     * 
     * @param testString The string to test for balanced brackets.
     * @return true if the brackets are balanced, false otherwise.
     */
    public static boolean test(String testString) {
        final Stack<Data> stack = new Stack<>();

        for(int idx = 0; idx < testString.length(); idx++) {
            final char c = testString.charAt(idx);
            
            final int bracketType = bracketType(c);
            
            if (bracketType == 1) {
                // Consume any data before the next bracket
                //
                final String dataText = consumeData(testString, idx);
                
                // Move move the index along by the number of characters
                // in the data.
                idx += dataText.length();
                
                // Push a new data object onto the stack.
                //
                stack.push(new Data(c, dataText));
            } else if (bracketType == -1) {
                if (stack.empty()) {
                    return false;
                }
                if (c == correspondingBracket(stack.peek().getBracketType())) {
                    Data data = stack.pop();
                    System.out.println(data.getData());
                } else {
                    break;
                }
            }
        }
        
        return stack.empty();
    }
    
    /**
     * consumeData()
     * 
     * @param source The source data string
     * @param index Where to search from in the source string
     * @return 
     */
    private static String consumeData(String source, int index) {
        String data = "";
        char ch;
        while(index < source.length() && bracketType(ch = source.charAt(index + 1)) == 0) {
            data += ch;
            index++;
        }
        return data.trim();
    }
    
    /**
     * bracketType()
     * 
     * @param c
     * @return +1 if an open bracket, -1 if a close bracket, 0 for anything else.
     */
    private static int bracketType(char c) {
        if (c == '(' || c == '[' || c == '<') {
            return 1;
        }
        if (c == ')' || c == ']' || c == '>') {
            return -1;
        }
        return 0;
    }

    /**
     * correspondingBracket()
     * 
     * @param bracketChar
     * @return the corresponding bracket to the input, or 0 for non-brackets.
     */
    private static char correspondingBracket(char bracketChar) {
        switch (bracketChar) {
            case '(':
                return ')';
            case '[':
                return ']';
            case '<':
                return '>';
            case ')':
                return '(';
            case ']':
                return '[';
            case '>':
                return '<';
            default:
                return 0;
        }
    }
}
