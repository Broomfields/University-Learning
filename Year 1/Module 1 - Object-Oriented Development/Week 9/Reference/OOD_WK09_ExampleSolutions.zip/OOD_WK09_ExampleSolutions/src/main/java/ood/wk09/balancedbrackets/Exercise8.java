/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.balancedbrackets;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

/**
 *
 * @author steven
 */
public class Exercise8 {

    public static void main(String[] args) {

        final List<String> TEST_STRINGS = Arrays.asList(
                "[ hello ( world < ! > ) ]",
                "[ hello ( world < ! ) > ]",
                "<<<<[[[[[[]]]]]]>>>>",
                "<<<<[[[[[]]]]]]>>>>",
                "<<<<[[[[[[[]]]]]]>>>>",
                "public static int main(String[] args){ /* some statements */ }",
                "<HELLO, WORLD![1234(ABC)]>",
                "<HELLO, WORLD![1234(ABC)[5678<DEF>]]>",
                "<HELLO, WORLD![1234(ABC)[5678<DEF>]]()>",
                "<THIS SHOULD FAIL!![1234(ABC)[5678<DEF>)]>");
        
        for(final String testString : TEST_STRINGS) {
            System.out.print(testString);
            if(BalancedBracketTester.test(testString)) {
                System.out.println(" is balanced");
            }
            else {
                System.out.println(" is not balanced");
            }
        }
    }
    
}

class BalancedBracketTester {
    /**
     * test()
     * 
     * @param testString The string to test for balanced brackets.
     * @return true if the brackets are balanced, false otherwise.
     */
    public static boolean test(String testString) {
        final Stack<Character> stack = new Stack<>();

        for (char c : testString.toCharArray()) {
            final int bracketType = bracketType(c);
            if (bracketType == 1) {
                stack.push(c);
            } else if (bracketType == -1) {
                if (stack.empty()) {
                    return false;
                }
                if (c == correspondingBracket(stack.peek())) {
                    stack.pop();
                } else {
                    break;
                }
            }
        }
        
        return stack.empty();
    }
    
    /**
     * bracketType()
     * 
     * @param c
     * @return +1 if an open bracket, -1 if a close bracket, 0 for anything else.
     */
    private static int bracketType(char c) {
        if (c == '(' || c == '[' || c == '<') {
            return 1;
        }
        if (c == ')' || c == ']' || c == '>') {
            return -1;
        }
        return 0;
    }

    /**
     * correspondingBracket()
     * 
     * @param bracketChar
     * @return the corresponding bracket to the input, or 0 for non-brackets.
     */
    private static char correspondingBracket(char bracketChar) {
        switch (bracketChar) {
            case '(':
                return ')';
            case '[':
                return ']';
            case '<':
                return '>';
            case ')':
                return '(';
            case ']':
                return '[';
            case '>':
                return '<';
            default:
                return 0;
        }
    }    
}
