/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.stacks;

import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author steven
 */
public class Main {
    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();
        Scanner in = new Scanner(System.in);
        
        System.out.println("Please enter a sentence: ");
        
        for(String s : in.nextLine().split(" ")) {
            stack.push(s);
        }
        
        while(!stack.empty()) {
            System.out.print(stack.pop() + " ");
        }
        System.out.println();
    }
}
