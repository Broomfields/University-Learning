/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.carsales;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author steven
 */
public class SalesHarness {

    private static final ArrayList<Integer> validOptions;
    private static Scanner in = new Scanner(System.in);

    static {
        validOptions = new ArrayList<>();
        validOptions.add(1);
        validOptions.add(2);
        validOptions.add(3);
        validOptions.add(4);
        validOptions.add(5);
        validOptions.add(0);
    }

    /**
     * main()
     * 
     * @param args 
     */
    public static void main(String[] args) {
        CarSales sales = new CarSales();

        sales.addCar("Ford", "Focus", "NU70 YBX", 20000);
        sales.addCar("Nissan", "Micra", "YP53 HZZ", 1100);

        boolean finished = false;

        do {
            displayOptions();

            int option = getOption();

            switch (option) {
                case 1:
                    displayAllSales(sales);
                    break;
                case 2:
                    addNewCarSale(sales);
                    break;
                case 3:
                    removeSale(sales);
                    break;
                case 4:
                    System.out.println("Total Value of Sales is: " + sales.totalValue());
                    break;
                case 5:
                    sales.clearCars();
                    break;
                case 0:
                    finished = true;
                    break;
            }
        } while (!finished);

        System.out.println("Program Terminated");
    }

    /**
     * getOption()
     * 
     * @return 
     */
    private static int getOption() {
        while (true) {
            try {
                int option = in.nextInt();

                if (validOptions.contains(option)) {
                    if(in.hasNextLine())
                        in.nextLine();
                    return option;
                } else {
                    System.out.println("Error! " + option + " is not a valid option.");
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Error! Invalid input, numbers only please!");
                in.next();
            }
        }
    }

    /**
     * displayOptions()
     * 
     */
    private static void displayOptions() {
        System.out.println("--------------------------------");
        System.out.println("1. List all sales.");
        System.out.println("2. Add sale.");
        System.out.println("3. Remove sale.");
        System.out.println("4. Print total value.");
        System.out.println("5. Remove all.");
        System.out.println("0. Quit.");
        System.out.println("--------------------------------\n");
        System.out.println("Please enter an option: ");
    }

    /**
     * displayAllSales()
     * 
     * @param sales 
     */
    private static void displayAllSales(CarSales sales) {
        System.out.println(sales.toString());
    }

    /**
     * addNewCarSale()
     * 
     * @param sales 
     */
    private static void addNewCarSale(CarSales sales) {
        System.out.println("Please enter the make: ");
        String make = in.next();

        System.out.println("Please enter the model: ");
        String model = in.next();

        System.out.println("Please enter the registration: ");
        if(in.hasNextLine())
            in.nextLine();
        
        String registration = in.nextLine();

        System.out.println("Please enter the value: ");
        int value = in.nextInt();

        // ... Should validate the data ...
        sales.addCar(make, model, registration, value);
    }

    /**
     * removeSale()
     * 
     * @param sales 
     */
    private static void removeSale(CarSales sales) {
        System.out.println("Please enter the registration of the car to remove from the sales");

        String registration = in.nextLine().trim();
        System.out.println("Removing: " + registration);
        sales.removeCar(registration);
    }
}
