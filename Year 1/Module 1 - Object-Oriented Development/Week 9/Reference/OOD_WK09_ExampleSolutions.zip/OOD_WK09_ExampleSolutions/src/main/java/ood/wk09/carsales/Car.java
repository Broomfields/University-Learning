/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.carsales;

/**
 *
 * @author steven
 */
public class Car {
    private String make;
    private String model;
    private String reg;
    private int value;

    /**
     * Car()
     * 
     * @param make
     * @param model
     * @param reg
     * @param value 
     */
    public Car(String make, String model, String reg, int value) {
        this.make = make;
        this.model = model;
        this.reg = reg;
        this.value = value;
    }

    /**
     * getMake()
     * 
     * @return 
     */
    public String getMake() {
        return make;
    }

    /**
     * getModel()
     * 
     * @return 
     */
    public String getModel() {
        return model;
    }

    /**
     * getReg()
     * 
     * @return 
     */
    public String getReg() {
        return reg;
    }

    /**
     * getValue()
     * 
     * @return 
     */
    public int getValue() {
        return value;
    }

    /**
     * toString()
     * 
     * @return 
     */
    @Override
    public String toString() {
        return "Car{" + "make=" + make + ", model=" + model + ", reg=" + reg + ", value=" + value + '}';
    }
    
}
