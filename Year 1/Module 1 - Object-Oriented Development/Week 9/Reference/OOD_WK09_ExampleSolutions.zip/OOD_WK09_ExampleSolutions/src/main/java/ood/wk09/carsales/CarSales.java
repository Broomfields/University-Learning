/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.carsales;

import java.util.ArrayList;

/**
 *
 * @author steven
 */
public class CarSales {

    private ArrayList<Car> cars;

    /**
     * CarSales()
     * 
     */
    public CarSales() {
        this.cars = new ArrayList<>();
    }

    /**
     * addCar()
     *
     * @param make
     * @param model
     * @param reg
     * @param value
     */
    public void addCar(String make, String model, String reg, int value) {
        Car car = new Car(make, model, reg, value);
        cars.add(car);
    }

    /**
     * removeCar()
     *
     * @param reg
     */
    public void removeCar(String reg) {
        Car carToRemove = null;

        for (Car car : cars) {
            if (car.getReg().equals(reg)) {
                carToRemove = car;
                break;
            }
        }

        if (carToRemove != null) {
            cars.remove(carToRemove);
        }
    }

    /**
     * clearCars()
     *
     */
    public void clearCars() {
        cars.clear();
    }

    /**
     * totalValue()
     *
     * @return
     */
    public int totalValue() {
        int tot = 0;

        for (Car c : cars) {
            tot += c.getValue();
        }

        return tot;
    }

    /**
     * toString()
     * 
     * @return 
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        if (cars.isEmpty()) {
            sb.append("NO SALES");
        } else {
            sb.append("CarSales{\n\tcars=\n");
            for (Car c : cars) {
                sb.append("\t\t");
                sb.append(c);
                sb.append("\n");
            }
            sb.append('}');
        }
        return sb.toString();
    }

    /**
     * toString()
     *
     * @return
     */
}
