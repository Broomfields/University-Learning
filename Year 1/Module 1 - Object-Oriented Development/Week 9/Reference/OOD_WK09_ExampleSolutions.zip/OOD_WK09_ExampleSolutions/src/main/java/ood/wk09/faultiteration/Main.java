/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.faultiteration;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Random;

/**
 *
 * @author steven
 */
public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        ArrayList<Integer> listOfIntegers = new ArrayList<>();
        
        for(int n = 0; n < 100; n++) {
            listOfIntegers.add(random.nextInt(200));
        }
        
        /*
            Faulty Code...
        for(Integer i : listOfIntegers) {
            if(i % 15 == 0) {
                listOfIntegers.remove(i);
                continue;
            }
            System.out.println(i);
        }
        */
        
        /*
            Working Code using ListIterator
        */
        ListIterator<Integer> li = listOfIntegers.listIterator();
        
        System.out.println("Length of the ArrayList: " + listOfIntegers.size());
        
        while(li.hasNext()) {
            int value = li.next();
            if(value % 15 == 0) {
                System.out.println("*** Removing: " + value);
                li.remove();
            }
            else {
                System.out.println(value);
            }
        }
        
        System.out.println("Length of the ArrayList: " + listOfIntegers.size());
        
    }
    
    public static void testIterator(ArrayList<Integer> listOfIntegers) {

    }
}
