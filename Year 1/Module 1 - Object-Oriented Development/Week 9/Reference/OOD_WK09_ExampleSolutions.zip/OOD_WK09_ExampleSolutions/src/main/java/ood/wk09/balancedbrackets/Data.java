/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk09.balancedbrackets;

/**
 *
 * @author steven
 * 
 * Class to hold the open bracket and associated data.
 */
public class Data {
    private char bracketType;
    private String data;

    /**
     * Data() - Constructor
     * @param bracketType
     * @param data 
     */
    public Data(char bracketType, String data) {
        this.bracketType = bracketType;
        this.data = data;
    }

    /**
     * getBracketType()
     * 
     * @return 
     */
    public char getBracketType() {
        return bracketType;
    }

    /**
     * getData()
     * 
     * @return 
     */
    public String getData() {
        return data;
    }    
}
