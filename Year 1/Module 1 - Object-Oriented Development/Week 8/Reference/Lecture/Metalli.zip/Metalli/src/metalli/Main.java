/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metalli;

import java.util.Scanner;

/**
 *
 * @author u0029190
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        
        MetalliSign sign = new MetalliSign();
        System.out.println(sign.toString());
        
        
        // SET MATERIAL
        int option = 0;
        do {// do is an EXIT controlled loop
            
            System.out.println("\n1. Aluminium");
            System.out.println("2. Brass");
            System.out.println("3. Stainless Steel");
            System.out.print("Please specify metal (1-3): ");
            
            try {
                option = scan.nextInt();
            }
            catch (Exception e) { // Catch all Exceptions 
                                  // Can we be more specific?
                option = 0;
                scan.nextLine(); // Clear the buffer ready for next iteration
            }
        }
        while(option < 1 || option > 3); 
        
        switch (option ){
            case 1: 
                sign.setMaterial(Material.ALUMINIUM);
                break;
            case 2: 
                sign.setMaterial(Material.BRASS);
                break;
            case 3: 
                sign.setMaterial(Material.STAINLESSSTEEL);
                break;
        }
        
        // SET SIZE
        // We are REPEATING code here, can we refactor into a method?
        option = 0;
        do {
            
            System.out.println("\n1. Small");
            System.out.println("2. Medium");
            System.out.println("3. Large");
            System.out.print("Please specify size (1-3): ");
            
            try {
                option = scan.nextInt();
            }
            catch (Exception e) { // Catch all Exceptions 
                                  // Can we be more specific?
                option = 0;
                scan.nextLine(); // Clear the buffer ready for next iteration
            }
        }
        while(option < 1 || option > 3); 
        
        switch (option ){
            case 1: 
                sign.setSize(Size.SMALL);
                break;
            case 2: 
                sign.setSize(Size.MEDIUM);
                break;
            case 3: 
                sign.setSize(Size.LARGE);
                break;
        }
        
        // SET Silhouette Picture
        String choice = "";
        do {
            
            System.out.print("\nSilhouette Picture required (y/n): ");
            
            try {
                choice = scan.next();
            }
            catch (Exception e) { // Catch all Exceptions 
                                  // Can we be more specific?
                choice = "";
                scan.nextLine(); // Clear the buffer ready for next iteration
            }
        }
        while(!choice.equals("y") && !choice.equals("n")); 
        
        // choice.equals("y") will evaluate to true or false
        // meaning we can pass this stright to the setSilhouette
        // method (that expects a boolean)
        sign.setSilhouette(choice.equals("y")); 
        
        // Print details of the resulting sign
        System.out.println("\nFinal Sign\n" + sign.toString());
    }
}
