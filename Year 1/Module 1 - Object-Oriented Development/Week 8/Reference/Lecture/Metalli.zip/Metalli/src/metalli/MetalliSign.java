/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metalli;

/**
 *
 * @author u0029190
 */
public class MetalliSign {
    // Attributes
    private Material material;
    private Size size;
    private boolean silhouette;  
    
    // Constructors
    public MetalliSign() {
        this(Material.ALUMINIUM, Size.SMALL);
    }

    public MetalliSign(Material material, Size size) {
        this(material, size, false);
    }

    public MetalliSign(Material material, Size size, boolean silhouette) {
        this.material = material;
        this.size = size;
        this.silhouette = silhouette;
    }
    
    // Getters and Setters
    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public boolean isSilhouette() {
        return silhouette;
    }

    public void setSilhouette(boolean silhouette) {
        this.silhouette = silhouette;
    }
    
    // Additional Methods
    public double calculteCost() {
        
        double cost = 0.0;
        
        switch (this.material) {
            case ALUMINIUM:
                switch (this.size) {
                    case SMALL:
                        cost = 18.51;
                        break;
                    case MEDIUM:
                        cost = 18.51;
                        break;
                    case LARGE:
                        cost = 18.51;
                        break;
                }
                break;
            case BRASS:
                switch (this.size) {
                    case SMALL:
                        cost = 21.35;
                        break;
                    case MEDIUM:
                        cost = 28.50;
                        break;
                    case LARGE:
                        cost = 34.55;
                        break;
                }
                break;
            case STAINLESSSTEEL:
                switch (this.size) {
                    case SMALL:
                        cost = 20.77;
                        break;
                    case MEDIUM:
                        cost = 27.72;
                        break;
                    case LARGE:
                        cost = 33.60;
                        break;
                }
                break;
        }
        
        if (this.silhouette) {
            cost += 4.5;
        }
        
        return cost;
    }

    @Override
    public String toString() {
        return "MetalliSign{" + "material=" + material + ", size=" + size + ", silhouette=" + silhouette + ", cost=" + this.calculteCost() + '}';
    }
    
}




