/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.televisionrecorder;

import java.time.LocalDateTime;

/**
 *
 * @author steven
 */
public class TelevisionRecorder {
    private int channel;
    private LocalDateTime scheduledStartTime;
    private LocalDateTime scheduledEndTime;
    private boolean isRecording;
    
    public TelevisionRecorder(int channel) {
        this(channel, null, null);
    }
    
    public TelevisionRecorder(int channel, LocalDateTime scheduledStartTime, LocalDateTime scheduledEndTime) {
        this.channel = channel;
        this.scheduledStartTime = scheduledStartTime;
        this.scheduledEndTime = scheduledEndTime;
    }
    
    public void instantRecord() {
        if(isRecording) {
            System.out.println("Already recording.");
            return;
        }
        System.out.println("Instant recording started.");
        isRecording = true;
    }
    
    public void stopRecording() {
        if(!isRecording)
            System.out.println("Wasn't recording.");
        else {
            System.out.println("Recording stopped.");
            isRecording = false;
        }
    }
    
    public void setChannel(int channel) {
        if(isRecording) {
            System.out.println("Can't change channel, currently recording.");
            return;
        }
        else if(hasScheduledRecording()) {
            System.out.println("Can't change channel, have a scheduled recording.");
        }
        this.channel = channel;
    }
    
    public boolean run() {
        if(!isRecording && hasScheduledRecording()) {
            if(LocalDateTime.now().isAfter(scheduledStartTime)) {
                System.out.println("Recording has started.");
                isRecording = true;
            }
        }
        else if(isRecording && hasScheduledRecording()) {
            if(LocalDateTime.now().isAfter(scheduledEndTime)) {
                System.out.println("Recording has finished.");
                isRecording = false;
                return false;
            }
        }
        return true;
    }
    
    public void cancelScheduledRecording() {
        if(hasScheduledRecording()) {
            scheduledStartTime = null;
            scheduledEndTime = null;
        }
    }
    
    public boolean hasScheduledRecording() {
        return scheduledStartTime != null && scheduledEndTime != null;
    }
}
