/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.robotwars;

import java.util.Random;

/**
 * Robot
 * 
 * @author steven
 */
public class Robot {
    public static Random random = new Random();
    
    private int hitPoints, strength, batteryPower;
    private String name;

    /**
     * Constructor
     * 
     * @param hitPoints
     * @param strength 
     */
    public Robot(String name, int hitPoints, int strength) {
        this.name = name;
        this.hitPoints = hitPoints;
        this.strength = strength;
        this.batteryPower = 100; // 0 - 100%
    }
    
    /**
     * attack()
     * 
     * @param other 
     */
    public void attack(Robot other) {
        if(random.nextInt(100) <= 10) {
            System.out.println(name + " Kernel Panic!!! Attack Failed!");
            return;
        }
        
        int damage = random.nextInt(strength);
        
        if(batteryPower < 25) {
            System.out.println(name + " is low on power, damage reduced by 50%");
            damage /= 2;
        }
        
        other.takeDamage(damage);
        
        consumePower(damage);
    }
    
    /**
     * takeDamage()
     * 
     * @param amount 
     */
    public void takeDamage(int amount) {
        if(random.nextInt(100) <= 5) {
            System.out.println(name + " 010001001! Evaded the attack!");
            return;
        }
        
        hitPoints -= amount;
        
        System.out.println(name + " has taken " + amount + " damage - hitpoints = " + hitPoints);
        
        if(isDead()) {
            System.out.println(name + " IS 0xDEADBEEF!!!");
        }
        else {
            System.out.println(this);
        }
    }
    
    /**
     * isDead()
     * 
     * @return 
     */
    public boolean isDead() {
        return hitPoints <= 0;
    }
    
    /**
     * consumePower()
     * 
     * @param damageInflicted 
     */
    private void consumePower(int damageInflicted) {
        int pc = (int) ((damageInflicted / (double) strength) * 100);
        
        if(pc == 0)
            return;
        if(pc <= 25)
            batteryPower--;
        else if(pc <= 50)
            batteryPower -= 2;
        else if(pc <= 75)
            batteryPower -= 3;
        else if(pc <= 100)
            batteryPower -= 4;
    }

    /**
     * toString()
     * 
     * @return 
     */
    @Override
    public String toString() {
        return name + " {" + "hitPoints=" + hitPoints + ", strength=" + strength + ", batteryPower=" + batteryPower + '}';
    }
    
    
}
