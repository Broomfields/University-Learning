/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.clock;

/**
 *
 * @author steven
 */
public class TestClock {
    public static void main(String[] args) {
        Clock c1 = new Clock(3672);
        Clock c2 = new Clock(51303);
        
        System.out.println(c1.getSeconds() + " = " + c1.getTime());
        System.out.println(c2.getSeconds() + " = " + c2.getTime());
    }
}
