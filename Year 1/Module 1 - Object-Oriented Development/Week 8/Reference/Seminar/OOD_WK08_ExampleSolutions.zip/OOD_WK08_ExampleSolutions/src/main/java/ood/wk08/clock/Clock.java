/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.clock;

/**
 *
 * @author steven
 */
public class Clock {

    private int seconds;

    public Clock() {
        this(0);
    }
    
    public Clock(int seconds) {
        this.seconds = seconds;
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }
    
    public String getTime() {
        int hours, mins, secs;
        
        secs = seconds % 60;
        mins = (seconds / 60) % 60;
        hours = (seconds / 60) / 60;
        
        return String.format("%02d:%02d:%02d", hours, mins, secs);
    }
}
