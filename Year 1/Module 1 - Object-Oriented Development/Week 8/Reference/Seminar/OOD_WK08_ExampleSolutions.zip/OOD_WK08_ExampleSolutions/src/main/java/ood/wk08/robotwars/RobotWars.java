/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.robotwars;

/**
 *
 * @author steven
 */
public class RobotWars {
    public static void main(String[] args) {
        Robot robbie = new Robot("Robbie", 200, 17);
        Robot micky = new Robot("Micky", 276, 12);
        
        while(!robbie.isDead() && !micky.isDead()) {
            
            robbie.attack(micky);
            
            if(!micky.isDead())
                micky.attack(robbie);
        }
    }
}
