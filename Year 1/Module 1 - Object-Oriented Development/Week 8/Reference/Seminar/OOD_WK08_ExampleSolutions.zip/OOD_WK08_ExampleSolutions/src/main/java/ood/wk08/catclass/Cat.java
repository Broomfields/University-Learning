/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.catclass;

/**
 *
 * @author steven
 */
public class Cat {
    private String name;
    private int age;
    private boolean friendly;

    public Cat(String name, int age) {
        this(name, age, true);
    }
    
    public Cat(String name, int age, boolean friendly) {
        this.name = name;
        this.age = age;
        this.friendly = friendly;
    }

    public String getName() {
        return name;
    }
    
//    public String meet(Cat other) {
//        return this.name + " meets " + other.name + ", they ignore each other!";
//    }
    
    public String meet(Cat other) {
        if(!friendly && !other.friendly)
            return "The cats fight!";
        else if(!friendly && other.friendly)
            return this.name + " hisses at " + other.name;
        else if(friendly && !other.friendly)
            return this.name + " gets hissed at by " + other.name;
        else
            return this.name + " meets " + other.name + ", they ignore each other!";
    }    

    public boolean isFriendly() {
        return friendly;
    }
    
    public int getAgeInHumanYears() {
        if(age == 0)
            return 0;
        else if(age == 1)
            return 15;
        else if(age == 2)
            return 24;
        else
            return 24 + (age - 2) * 4;
    }
}
