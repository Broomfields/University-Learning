/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.television;

/**
 *
 * @author steven
 */
public class TestTelevision {
    public static void main(String[] args) {
        Television tv1 = new Television(4, 8, true);
        Television tv2 = new Television(1, 10, false);
        
        System.out.println(String.format("TV1:: Channel: %d - Volume: %d - Power Is On: %b", tv1.getChannel(), tv1.getVolume(), tv1.hasPower()));
        System.out.println(String.format("TV2:: Channel: %d - Volume: %d - Power Is On: %b", tv2.getChannel(), tv2.getVolume(), tv2.hasPower()));
    }
}
