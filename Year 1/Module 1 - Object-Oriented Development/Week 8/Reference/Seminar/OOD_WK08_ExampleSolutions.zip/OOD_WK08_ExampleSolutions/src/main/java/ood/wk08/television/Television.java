/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.television;

/**
 *
 * @author steven
 */
public class Television {
    private int channel;
    private int volume;
    private boolean power;
    
    public Television(int c, int v, boolean p) {
        channel = c;
        volume = v;
        power = p;
    }

    public int getChannel() {
        return channel;
    }

    public int getVolume() {
        return volume;
    }

    public boolean hasPower() {
        return power;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public void setPower(boolean power) {
        this.power = power;
    }
    
}
