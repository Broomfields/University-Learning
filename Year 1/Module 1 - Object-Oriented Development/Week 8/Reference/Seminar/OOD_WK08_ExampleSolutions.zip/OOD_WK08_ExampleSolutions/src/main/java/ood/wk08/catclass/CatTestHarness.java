/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.catclass;

/**
 *
 * @author steven
 */
public class CatTestHarness {
    public static void main(String[] args) {
        Cat tiddles = new Cat("Tiddles", 1, true);
        Cat felix = new Cat("Felix", 2, false);
        Cat fluffy = new Cat("Fluffy", 10);
        
        displayCatHumanYears(tiddles);
        displayCatHumanYears(felix);
        displayCatHumanYears(fluffy);
        
        whenTwoCatsMeet(tiddles, felix);
        whenTwoCatsMeet(tiddles, fluffy);
        whenTwoCatsMeet(felix, fluffy);
    }
    
    private static void displayCatHumanYears(Cat cat) {
        System.out.println(cat.getName() + " is age " + cat.getAgeInHumanYears() + " in human years");
    }
    
    private static void whenTwoCatsMeet(Cat a, Cat b) {
        System.out.println(a.meet(b));
    }
}
