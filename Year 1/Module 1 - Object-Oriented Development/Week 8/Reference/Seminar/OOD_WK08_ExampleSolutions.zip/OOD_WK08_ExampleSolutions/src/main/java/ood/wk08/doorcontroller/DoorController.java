/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.doorcontroller;

/**
 *
 * @author steven
 */
public class DoorController {
    final private int maxOccupancy;
    private int currentOccupancy;

    public DoorController() {
        this(10);
    }
    
    public DoorController(int maxOccupancy) {
        this.maxOccupancy = maxOccupancy;
        this.currentOccupancy = 0;
    }
    
    public boolean enter() {
        if(currentOccupancy < maxOccupancy) {
            currentOccupancy++;
            return true;
        }
        return false;
    }
    
    public void exit() {
        if(currentOccupancy > 0) {
            currentOccupancy--;
        }
    }
}
