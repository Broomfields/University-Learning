/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.televisionrecorder;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author steven
 */
public class TestTelevisionRecorder {
    public static void main(String[] args) {
        TelevisionRecorder tr = new TelevisionRecorder(1);
        
        tr.instantRecord();
        
        tr.setChannel(5);
        
        tr.stopRecording();
        
        // Scheduled Recording.
        System.out.println("Scheduled TelevisionRecorder test.");
        
        TelevisionRecorder scheduledRecorder = new TelevisionRecorder(2, LocalDateTime.now().plusSeconds(5), LocalDateTime.now().plusSeconds(10));
        
        Random random = new Random();
        
        while(scheduledRecorder.run()) {
            int rand = random.nextInt(100);
//             System.out.println("---> " + rand);
            if(rand <= 20) { // random attempt to change the channel.
                scheduledRecorder.setChannel(random.nextInt(6));
            }
            
            try {
                Thread.sleep(250);
            } catch (InterruptedException ex) {
                Logger.getLogger(TestTelevisionRecorder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        System.out.println("Program Terminated.");
    }
}
