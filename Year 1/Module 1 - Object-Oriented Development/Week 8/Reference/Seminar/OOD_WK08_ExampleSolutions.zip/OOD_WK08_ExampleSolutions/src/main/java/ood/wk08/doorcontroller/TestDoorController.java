/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood.wk08.doorcontroller;

/**
 *
 * @author steven
 */
public class TestDoorController {
    public static void main(String[] args) {
        DoorController dc1 = new DoorController(5);
        
        attemptEntry(dc1, "Jack");
        attemptEntry(dc1, "Sue");
        attemptEntry(dc1, "Bob");
        attemptEntry(dc1, "Jill");
        attemptEntry(dc1, "Hilary");
        attemptEntry(dc1, "Steven");
        
        dc1.exit();
        
        attemptEntry(dc1, "Harry");
        attemptEntry(dc1, "Steven");
        
    }
    
    private static void attemptEntry(DoorController dc, String name) {
        System.out.print(String.format("%-12s - ", name));
        if(dc.enter()) {
            System.out.println("Entry Permitted!");
        }
        else {
            System.out.println("** Entry Denied! **");
        }
    }
}
